import React, { useState, useEffect, useMemo, useContext } from "react";

// ── Data ─────────────────────────────────────────────────────────────────────

const JURISDICTIONS_US = [
  "Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut",
  "Delaware","Florida","Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa",
  "Kansas","Kentucky","Louisiana","Maine","Maryland","Massachusetts","Michigan",
  "Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada",
  "New Hampshire","New Jersey","New Mexico","New York State","New York City",
  "North Carolina","North Dakota","Ohio","Oklahoma","Oregon","Pennsylvania",
  "Rhode Island","South Carolina","South Dakota","Tennessee","Texas","Utah",
  "Vermont","Virginia","Washington","West Virginia","Wisconsin","Wyoming",
];
const JURISDICTIONS_CA = [
  "Ontario","Quebec","British Columbia","Alberta","Manitoba","Saskatchewan",
  "Nova Scotia","New Brunswick","Prince Edward Island","Newfoundland","Labrador",
];
const ALL_JURISDICTIONS = [...JURISDICTIONS_US, ...JURISDICTIONS_CA];
const isProvince = (j) => JURISDICTIONS_CA.includes(j);

const INSTITUTION_TYPES = [
  // Lords Sovereign tier
  "Federal Monarchy","Federal Executive","Congress",
  "Supreme Court","Armed Forces",
  "State Monarchy","State Executive","State Legislature","State Judiciary",
  "Provincial Monarchy","Provincial Executive","Provincial Legislature","Provincial Judiciary",
  // Lords of the Estates tier
  "Federal Peerage","State Peerage","Provincial Peerage",
  // Honours tier
  "Federal Hereditary Knighthood","State Hereditary Knighthood","Provincial Hereditary Knighthood",
  "Federal Knightly Order","State Knightly Order","Provincial Knightly Order",
  "Federal Civil Honour","State Civil Honour","Provincial Civil Honour",
];

// ── Sovereignty map ───────────────────────────────────────────────────────────
const SOVEREIGNTY_MAP = {
  "Federal":              "Empire",
  "Alabama":              "Grand Duchy",
  "Alaska":               "Kingdom",
  "Arizona":              "Kingdom",
  "Arkansas":             "Great Marquisate",
  "California":           "Principality",
  "Colorado":             "Grand Duchy",
  "Connecticut":          "Great Marquisate",
  "Delaware":             "Great Marquisate",
  "Florida":              "Kingdom",
  "Georgia":              "Earldom-Palatinate",
  "Hawaii":               "Kingdom",
  "Idaho":                "Viscountcy-Palatinate",
  "Illinois":             "Grand Duchy",
  "Indiana":              "Great Marquisate",
  "Iowa":                 "Earldom-Palatinate",
  "Kansas":               "Viscountcy-Palatinate",
  "Kentucky":             "Earldom-Palatinate",
  "Louisiana":            "Great Marquisate",
  "Maine":                "Kingdom",
  "Maryland":             "Principality",
  "Massachusetts":        "Grand Duchy",
  "Michigan":             "Principality",
  "Minnesota":            "Viscountcy-Palatinate",
  "Mississippi":          "Earldom-Palatinate",
  "Missouri":             "Great Marquisate",
  "Montana":              "Free Barony",
  "Nebraska":             "Viscountcy-Palatinate",
  "Nevada":               "Free Barony",
  "New Hampshire":        "Grand Duchy",
  "New Jersey":           "Earldom-Palatinate",
  "New Mexico":           "Principality",
  "New York State":       "Principality",
  "New York City":        "Kingdom",
  "North Carolina":       "Principality",
  "North Dakota":         "Earldom-Palatinate",
  "Ohio":                 "Kingdom",
  "Oklahoma":             "Free Barony",
  "Oregon":               "Great Marquisate",
  "Pennsylvania":         "Principality",
  "Rhode Island":         "Great Marquisate",
  "South Carolina":       "Principality",
  "South Dakota":         "Earldom-Palatinate",
  "Tennessee":            "Earldom-Palatinate",
  "Texas":                "Kingdom",
  "Utah":                 "Kingdom",
  "Vermont":              "Principality",
  "Virginia":             "Kingdom",
  "Washington":           "Grand Duchy",
  "West Virginia":        "Principality",
  "Wisconsin":            "Principality",
  "Wyoming":              "Free Barony",
  // Canadian Provinces
  "Ontario":              "Principality",
  "Quebec":               "Kingdom",
  "British Columbia":     "Earldom-Palatinate",
  "Alberta":              "Great Marquisate",
  "Manitoba":             "Great Marquisate",
  "Saskatchewan":         "Free Barony",
  "Nova Scotia":          "Kingdom",
  "New Brunswick":        "Kingdom",
  "Prince Edward Island": "Grand Duchy",
  "Newfoundland":         "Earldom-Palatinate",
  "Labrador":             "Viscountcy-Palatinate",
};

// [masculine title, feminine title] per sovereignty type
const SOVEREIGNTY_TITLES = {
  "Empire":                ["Emperor (勇主皇)",          "Empress (勇主皇)"],
  "Kingdom":               ["King (王)",                  "Queen (王)"],
  "Principality":          ["Prince (主公)",              "Princess (主公)"],
  "Grand Duchy":           ["Grand Duke (大公)",          "Grand Duchess (大公)"],
  "Great Marquisate":      ["Great Marquess (大侯)",      "Great Marchioness (大侯)"],
  "Earldom-Palatinate":    ["Earl Palatine (大伯)",       "Countess Palatine (大伯)"],
  "Viscountcy-Palatinate": ["Viscount Palatine (大爵)",   "Viscountess Palatine (大爵)"],
  "Free Barony":           ["Free Baron (自爵)",          "Free Baroness (自爵)"],
};

// Returns [maleLabel, femaleLabel] for a jurisdiction (or "Federal")
const getSovereignTitles = (jur) => {
  const sov = SOVEREIGNTY_MAP[jur];
  return sov ? SOVEREIGNTY_TITLES[sov] : ["Sovereign", "Sovereign"];
};

const NOBLE_COURT_POSITIONS = [
  "Regent","Crown Prince","Crown Princess",
  "Knight","Dame","Lord/Lady in Waiting","Royal Chamberlain",
  "Master of the Household","Herald","Seneschal",
];

const INST_POSITIONS = {
  // All Lords Sovereign hold the style of Majesty regardless of rank.
  // Address is always by sovereign title — Lord/Lady/Gent never applies.
  "Federal Monarchy": [
    "Emperor (勇主皇) — His/Her Majesty",
    "Empress (勇主皇) — His/Her Majesty",
    "Regent",
    "Crown Prince","Crown Princess",
    "Archduke","Archduchess","Imperial Chancellor",
    "Lord High Steward","Grand Master of Ceremonies","Imperial Herald",
    "Knight","Dame","Lord/Lady in Waiting","Royal Chamberlain","Master of the Household",
  ],
  "State Monarchy":      NOBLE_COURT_POSITIONS,
  "Provincial Monarchy": NOBLE_COURT_POSITIONS,
  "Federal Executive": ["President","Vice President","Secretary of State","Secretary of the Treasury","Secretary of Defense","Attorney General","Secretary of the Interior","Secretary of Agriculture","Secretary of Commerce","Secretary of Labor","Secretary of HHS","Secretary of HUD","Secretary of Transportation","Secretary of Energy","Secretary of Education","Secretary of Veterans Affairs","Secretary of Homeland Security","White House Chief of Staff","National Security Advisor","Director of National Intelligence","Director of the CIA","Surgeon General","Ambassador"],
  // Congress — tricameral: House of Representatives, Senate, and the Regal Ministry
  // (House of Lords-esque third chamber; votes by state/province delegation).
  "Congress": [
    "Representative","Speaker of the House","House Majority Leader","House Minority Leader","House Majority Whip","House Minority Whip","House Committee Chair",
    "Senator","President of the Senate","Senate Majority Leader","Senate Minority Leader","Senate Majority Whip","Senate Minority Whip","President pro tempore",
    "Chairman of the Regal Ministry","Chairwoman of the Regal Ministry","Chairman pro tempore of the Regal Ministry","Chairwoman pro tempore of the Regal Ministry","Regalminister","Adjutant-Grandee",
  ],
  "Supreme Court": ["Chief Justice of the Supreme Court","Associate Justice of the Supreme Court","Circuit Court Judge","District Court Judge","Magistrate Judge"],
  "Armed Forces": [], // handled separately
  "State Executive": ["Governor","Lieutenant Governor","State Attorney General","State Secretary of State","State Treasurer","State Comptroller","State Auditor"],
  "State Legislature": ["State Senator","State Representative","President of the State Senate","Speaker of the State House","State Senate Majority Leader","State House Majority Leader"],
  "State Judiciary": ["Chief Justice of State Supreme Court","Associate Justice of State Supreme Court","State Appellate Judge","State Trial Court Judge"],
  "Provincial Executive": ["Premier","Deputy Premier","Provincial Attorney General","Provincial Finance Minister","Provincial Health Minister","Provincial Education Minister"],
  "Provincial Legislature": ["Member of Provincial Parliament","Speaker of the Legislature","Leader of the Official Opposition","Government House Leader"],
  "Provincial Judiciary": ["Chief Justice of Provincial Court","Provincial Court Judge","Superior Court Judge"],
  // ── Lords of the Estates ─────────────────────────────────────────────────
  // Primary address is always the peerage title.
  // Secondary address: Lord (generic) | Lady (female) | Gent (male).
  // Lords Sovereign are NOT addressed as Lord/Lady/Gent — they use their
  // sovereign title exclusively, all with the style of Majesty.
  "Federal Peerage": [
    // Dukes — alt. address: Gent (male), Lady (female), Lord (either)
    "Duke","Duchess",
    // Marquesses
    "Marquess","Marchioness",
    // Earls
    "Earl","Countess",
    // Viscounts
    "Viscount","Viscountess",
    // Barons
    "Baron","Baroness",
    // Generic / courtesy address forms
    "Lord (generic address)","Lady (female address)","Gent (male address)",
    "Hereditary Peer","Life Peer",
  ],
  "State Peerage": [
    "Duke","Duchess",
    "Marquess","Marchioness",
    "Earl","Countess",
    "Viscount","Viscountess",
    "Baron","Baroness",
    "Lord (generic address)","Lady (female address)","Gent (male address)",
    "Hereditary Peer","Life Peer",
  ],
  "Provincial Peerage": [
    "Duke","Duchess",
    "Marquess","Marchioness",
    "Earl","Countess",
    "Viscount","Viscountess",
    "Baron","Baroness",
    "Lord (generic address)","Lady (female address)","Gent (male address)",
    "Hereditary Peer","Life Peer",
  ],
  // ── Honours ──────────────────────────────────────────────────────────────
  // Hereditary knighthoods: Baronet / Hidalgo / Ritter (regional variant TBD).
  // Created by Lord Sovereign of jurisdiction (federal obligated to recognise),
  // or federally created and patriated. Titled Sir (male) / Dame (female).
  "Federal Hereditary Knighthood": [
    "Baronet — Sir","Baronet — Dame",
    "Hidalgo — Sir","Hidalgo — Dame",       // placeholder: regional variant
    "Ritter — Sir","Ritter — Dame",          // placeholder: regional variant
  ],
  "State Hereditary Knighthood": [
    "Baronet — Sir","Baronet — Dame",
    "Hidalgo — Sir","Hidalgo — Dame",
    "Ritter — Sir","Ritter — Dame",
  ],
  "Provincial Hereditary Knighthood": [
    "Baronet — Sir","Baronet — Dame",
    "Hidalgo — Sir","Hidalgo — Dame",
    "Ritter — Sir","Ritter — Dame",
  ],
  // Knightly orders: sovereign of the order determines granting authority.
  // Federal orders granted by Emperor; state/provincial orders by Lord Sovereign.
  // Non-hereditary. Titled Sir / Dame.
  "Federal Knightly Order": [
    "Knight — Sir","Knight — Dame",
    "Knight Commander — Sir","Knight Commander — Dame",
    "Knight Grand Cross — Sir","Knight Grand Cross — Dame",
    "Companion","Officer","Member",
  ],
  "State Knightly Order": [
    "Knight — Sir","Knight — Dame",
    "Knight Commander — Sir","Knight Commander — Dame",
    "Knight Grand Cross — Sir","Knight Grand Cross — Dame",
    "Companion","Officer","Member",
  ],
  "Provincial Knightly Order": [
    "Knight — Sir","Knight — Dame",
    "Knight Commander — Sir","Knight Commander — Dame",
    "Knight Grand Cross — Sir","Knight Grand Cross — Dame",
    "Companion","Officer","Member",
  ],
  // Civil honours: granted by heads of government (Presidents, Governors, Premiers).
  // Personal, non-hereditary, non-titular.
  "Federal Civil Honour": [
    "Presidential Medal of Freedom",
    "Presidential Medal of Merit",
    "National Medal of Arts",
    "National Medal of Science",
    "Congressional Gold Medal",
    "Presidential Citizens Medal",
  ],
  "State Civil Honour": [
    "Governor's Medal of Merit",
    "Governor's Award for Excellence",
    "State Medal of Honor",
    "State Medal of Freedom",
    "State Distinguished Service Medal",
  ],
  "Provincial Civil Honour": [
    "Premier's Award of Excellence",
    "Provincial Medal of Service",
    "Provincial Distinguished Service Award",
    "Order of the Province",
  ],
};

// Congress positions grouped by chamber, for optgroup rendering in the position picker.
const CONGRESS_CHAMBERS = [
  {
    label: "House of Representatives",
    positions: ["Representative","Speaker of the House","House Majority Leader","House Minority Leader","House Majority Whip","House Minority Whip","House Committee Chair"],
  },
  {
    label: "Senate",
    positions: ["Senator","President of the Senate","Senate Majority Leader","Senate Minority Leader","Senate Majority Whip","Senate Minority Whip","President pro tempore"],
  },
  {
    label: "Regal Ministry",
    positions: ["Chairman of the Regal Ministry","Chairwoman of the Regal Ministry","Chairman pro tempore of the Regal Ministry","Chairwoman pro tempore of the Regal Ministry","Regalminister","Adjutant-Grandee"],
  },
];

// Coast Guard abolished — absorbed into Navy.
const MIL_BRANCHES = ["Army","Navy","Air Force","Marine Corps","Space Force"];

// Per-branch rank lists (ascending order)
// Navy: Sub-Lieutenant replaces LT(JG); Captain-at-Sea replaces O-6 Captain.
// Air Force & Space Force: RAF-style throughout.
// O-0: Officer Cadet (Army/Marines), Midshipman (Navy), Pilot Officer (AF/SF).
// 1-star: Brigadier General (Army/Marines), Commodore Admiral (Navy), Air Commodore Marshal (AF/SF).
// 5-star (O-11): General and Field Marshal (Army), Captain General (Marines),
//         Fleet Admiral (Navy), Marshal of the Air/Space Force (AF/SF).
// O-11A: alternative five-star grade for governors-general of imperial possessions.
// O-12: department-level six-star ranks.
// O-13 (Dominus): reserved for state/provincial monarchs.
// O-14 (Imperator): reserved for the federal monarch.
const MIL_RANKS_BY_BRANCH = {
  "Army": [
    // Enlisted
    "Private","Private First Class","Corporal","Sergeant",
    "Staff Sergeant","Sergeant First Class","Master Sergeant","First Sergeant",
    "Sergeant Major","Command Sergeant Major","Sergeant Major of the Army",
    // Warrant Officers
    "Warrant Officer 1","Chief Warrant Officer 2","Chief Warrant Officer 3",
    "Chief Warrant Officer 4","Chief Warrant Officer 5",
    // Commissioned
    "Officer Cadet",
    "2nd Lieutenant","1st Lieutenant","Captain","Major",
    "Lieutenant Colonel","Colonel",
    // General Officers (1-5 star)
    "Brigadier General","Major General","Lieutenant General","General",
    "General and Field Marshal",
    // Alternative five-star (O-11A) - governors-general of imperial possessions
    "High General",
    // Six-star (O-12) - department level
    "General-in-Chief and Field Marshal of the Armies",
    // Seven-star (O-13) - state/provincial monarchs
    "Dominus-General",
    // Eight-star (O-14) - federal monarch
    "Imperator-General",
  ],
  "Navy": [
    // Enlisted
    "Seaman Recruit","Seaman Apprentice","Seaman",
    "Petty Officer 3rd Class","Petty Officer 2nd Class","Petty Officer 1st Class",
    "Chief Petty Officer","Senior Chief Petty Officer","Master Chief Petty Officer",
    "Fleet Master Chief Petty Officer",
    // Warrant Officers
    "Warrant Officer 1","Chief Warrant Officer 2","Chief Warrant Officer 3",
    "Chief Warrant Officer 4","Chief Warrant Officer 5",
    // Commissioned
    "Midshipman",
    "Ensign","Sub-Lieutenant","Lieutenant","Lieutenant Commander","Commander",
    "Captain-at-Sea",
    // Flag Officers (1-5 star)
    "Commodore Admiral","Rear Admiral","Vice Admiral","Admiral","Fleet Admiral",
    // Alternative five-star (O-11A)
    "High Admiral",
    // Six-star (O-12) - commands Navy and Marine Corps
    "Admiral of the Navy in General Captaincy",
    // Seven-star (O-13)
    "Dominus-Admiral",
    // Eight-star (O-14)
    "Imperator-Admiral",
  ],
  "Air Force": [
    // Enlisted (RAF-style)
    "Aircraftman","Leading Aircraftman","Senior Aircraftman","Corporal","Sergeant",
    "Flight Sergeant","Chief Technician","Warrant Officer","Master Aircrew",
    // Commissioned (RAF-style)
    "Pilot Officer",
    "Flying Officer (Junior Grade)","Flying Officer (Senior Grade)",
    "Flight Lieutenant","Squadron Leader",
    "Wing Commander","Group Captain",
    // Air Officers (1-5 star)
    "Air Commodore Marshal","Air Vice Marshal","Air Marshal","Air Chief Marshal",
    "Marshal of the Air Force",
    // Alternative five-star (O-11A)
    "High Marshal",
    // Six-star (O-12) - commands Air Force and Space Force
    "Grand Marshal of the Air and Space Forces",
    // Seven-star (O-13)
    "Dominus-Marshal",
    // Eight-star (O-14)
    "Imperator-Marshal",
  ],
  "Marine Corps": [
    // Enlisted
    "Private","Private First Class","Lance Corporal","Corporal","Sergeant",
    "Staff Sergeant","Gunnery Sergeant","Master Sergeant","First Sergeant",
    "Master Gunnery Sergeant","Sergeant Major","Sergeant Major of the Marine Corps",
    // Warrant Officers
    "Warrant Officer 1","Chief Warrant Officer 2","Chief Warrant Officer 3",
    "Chief Warrant Officer 4","Chief Warrant Officer 5",
    // Commissioned
    "Officer Cadet",
    "2nd Lieutenant","1st Lieutenant","Captain","Major",
    "Lieutenant Colonel","Colonel",
    // General Officers (1-5 star)
    "Brigadier General","Major General","Lieutenant General","General",
    "Captain General",
    // Alternative five-star (O-11A)
    "High General",
    // Six-star (O-12) - shared with Navy; Marine contexts use admiral styling
    "Admiral of the Navy in General Captaincy",
    // Seven-star (O-13) - Marine Corps uses admiral suffix (Navy department)
    "Dominus-Admiral",
    // Eight-star (O-14)
    "Imperator-Admiral",
  ],
  "Space Force": [
    // Enlisted
    "Specialist 1","Specialist 2","Specialist 3","Specialist 4",
    "Sergeant","Technical Sergeant","Master Sergeant","Senior Master Sergeant",
    "Chief Master Sergeant","Command Chief Master Sergeant",
    "Chief Master Sergeant of the Space Force",
    // Commissioned (RAF-style, mirroring Air Force)
    "Pilot Officer",
    "Flying Officer (Junior Grade)","Flying Officer (Senior Grade)",
    "Flight Lieutenant","Squadron Leader",
    "Wing Commander","Group Captain",
    // Space Officers (1-5 star)
    "Air Commodore Marshal","Air Vice Marshal","Air Marshal","Air Chief Marshal",
    "Marshal of the Space Force",
    // Alternative five-star (O-11A)
    "High Marshal",
    // Six-star (O-12) - commands Air Force and Space Force
    "Grand Marshal of the Air and Space Forces",
    // Seven-star (O-13)
    "Dominus-Marshal",
    // Eight-star (O-14)
    "Imperator-Marshal",
  ],
};

// NATO-style officer grades (O-0 through O-14) for every commissioned rank,
// keyed per branch since the same title can sit at different grades across services.
// Enlisted and warrant ranks are intentionally omitted — they use their own scales.
const MIL_OFFICER_GRADES = {
  "Army": {
    "Officer Cadet":"O-0",
    "2nd Lieutenant":"O-1","1st Lieutenant":"O-2","Captain":"O-3","Major":"O-4",
    "Lieutenant Colonel":"O-5","Colonel":"O-6",
    "Brigadier General":"O-7","Major General":"O-8","Lieutenant General":"O-9",
    "General":"O-10","General and Field Marshal":"O-11",
    "High General":"O-11A",
    "General-in-Chief and Field Marshal of the Armies":"O-12",
    "Dominus-General":"O-13","Imperator-General":"O-14",
  },
  "Navy": {
    "Midshipman":"O-0",
    "Ensign":"O-1","Sub-Lieutenant":"O-2","Lieutenant":"O-3","Lieutenant Commander":"O-4",
    "Commander":"O-5","Captain-at-Sea":"O-6",
    "Commodore Admiral":"O-7","Rear Admiral":"O-8","Vice Admiral":"O-9",
    "Admiral":"O-10","Fleet Admiral":"O-11",
    "High Admiral":"O-11A",
    "Admiral of the Navy in General Captaincy":"O-12",
    "Dominus-Admiral":"O-13","Imperator-Admiral":"O-14",
  },
  "Marine Corps": {
    "Officer Cadet":"O-0",
    "2nd Lieutenant":"O-1","1st Lieutenant":"O-2","Captain":"O-3","Major":"O-4",
    "Lieutenant Colonel":"O-5","Colonel":"O-6",
    "Brigadier General":"O-7","Major General":"O-8","Lieutenant General":"O-9",
    "General":"O-10","Captain General":"O-11",
    "High General":"O-11A",
    "Admiral of the Navy in General Captaincy":"O-12",
    "Dominus-Admiral":"O-13","Imperator-Admiral":"O-14",
  },
  "Air Force": {
    "Pilot Officer":"O-0",
    "Flying Officer (Junior Grade)":"O-1","Flying Officer (Senior Grade)":"O-2",
    "Flight Lieutenant":"O-3","Squadron Leader":"O-4",
    "Wing Commander":"O-5","Group Captain":"O-6",
    "Air Commodore Marshal":"O-7","Air Vice Marshal":"O-8","Air Marshal":"O-9",
    "Air Chief Marshal":"O-10","Marshal of the Air Force":"O-11",
    "High Marshal":"O-11A",
    "Grand Marshal of the Air and Space Forces":"O-12",
    "Dominus-Marshal":"O-13","Imperator-Marshal":"O-14",
  },
  "Space Force": {
    "Pilot Officer":"O-0",
    "Flying Officer (Junior Grade)":"O-1","Flying Officer (Senior Grade)":"O-2",
    "Flight Lieutenant":"O-3","Squadron Leader":"O-4",
    "Wing Commander":"O-5","Group Captain":"O-6",
    "Air Commodore Marshal":"O-7","Air Vice Marshal":"O-8","Air Marshal":"O-9",
    "Air Chief Marshal":"O-10","Marshal of the Space Force":"O-11",
    "High Marshal":"O-11A",
    "Grand Marshal of the Air and Space Forces":"O-12",
    "Dominus-Marshal":"O-13","Imperator-Marshal":"O-14",
  },
};

// Grade lookup for a rank within a given branch (undefined for enlisted/warrant ranks)
const gradeFor = (branch, rank) => MIL_OFFICER_GRADES[branch]?.[rank];

// The grades above the conventional five-star tier, which carry a highlighted
// badge and an explanatory note in the picker.
const MIL_ELEVATED_GRADES = new Set(["O-11A","O-12","O-13","O-14"]);

// Short explanation shown when one of the elevated grades is selected.
const MIL_GRADE_NOTE = {
  "O-11A": "Alternative five-star grade — for governors-general of the imperial possessions serving in the military.",
  "O-12":  "Six-star, department-level command, on par with the corresponding service secretary.",
  "O-13":  "Seven-star — reserved for state and provincial monarchs.",
  "O-14":  "Eight-star — reserved for the federal monarch (Emperor/Empress).",
};

// ── Colours & icons ───────────────────────────────────────────────────────────

const INST_COLOR = {
  "Federal Monarchy":"#c9a84c","State Monarchy":"#c9a84c","Provincial Monarchy":"#c9a84c",
  "Federal Executive":"#e05c3a","State Executive":"#d46b40","Provincial Executive":"#c87a50",
  "Congress":"#4a9eda","State Legislature":"#5aa4d0","Provincial Legislature":"#6aaec8",
  "Supreme Court":"#9b7fd4","State Judiciary":"#8b6fc4","Provincial Judiciary":"#7b5fb4",
  "Armed Forces":"#4caf82",
  // Lords of the Estates — deep rose/wine
  "Federal Peerage":"#c46a8a","State Peerage":"#b45a7a","Provincial Peerage":"#a44a6a",
  // Hereditary knighthoods — warm silver
  "Federal Hereditary Knighthood":"#b0a080","State Hereditary Knighthood":"#a09070","Provincial Hereditary Knighthood":"#908060",
  // Knightly orders — cool silver-blue
  "Federal Knightly Order":"#80a0b8","State Knightly Order":"#7090a8","Provincial Knightly Order":"#608098",
  // Civil honours — muted green-gold
  "Federal Civil Honour":"#8aaa60","State Civil Honour":"#7a9a50","Provincial Civil Honour":"#6a8a40",
};
const INST_ICON = {
  "Federal Monarchy":"♛","State Monarchy":"♛","Provincial Monarchy":"♛",
  "Federal Executive":"⚑","State Executive":"⚑","Provincial Executive":"⚑",
  "Congress":"⚖","State Legislature":"⚖","Provincial Legislature":"⚖",
  "Supreme Court":"⚖","State Judiciary":"⚖","Provincial Judiciary":"⚖",
  "Armed Forces":"✦",
  "Federal Peerage":"❦","State Peerage":"❦","Provincial Peerage":"❦",
  // Honours
  "Federal Hereditary Knighthood":"✠","State Hereditary Knighthood":"✠","Provincial Hereditary Knighthood":"✠",
  "Federal Knightly Order":"✙","State Knightly Order":"✙","Provincial Knightly Order":"✙",
  "Federal Civil Honour":"★","State Civil Honour":"★","Provincial Civil Honour":"★",
};
const col = (t) => INST_COLOR[t] || "#888";
const ico = (t) => INST_ICON[t] || "◆";

// Sex display helpers — two display modes, toggled via Settings
const SEX_LABEL_FULL   = { "Male":"Male♂", "Female":"Female♀" };
const SEX_LABEL_SYMBOL = { "Male":"♂", "Female":"♀" };

// Two colour schemes, toggled via Settings:
//  - "neutral": generic blue/red, no partisan reference
//  - "partisan": evokes the Democratic/Republican branding the summoned characters
//    co-opted in-world, brightened for legibility against the dark background
//    rather than reproducing the exact party hex values
const SEX_COLOR_SCHEMES = {
  neutral:  { "Male":"#4a9eda", "Female":"#e05c7a" },
  partisan: { "Male":"#2b5fd9", "Female":"#d81f2a" },
};
const sexColorFor = (sex, scheme="neutral") =>
  (SEX_COLOR_SCHEMES[scheme] || SEX_COLOR_SCHEMES.neutral)[sex];
const sexGlowFor = (sex, scheme="neutral") => {
  const c = sexColorFor(sex, scheme);
  return c ? `0 0 6px ${c}88, 0 0 12px ${c}44` : "none";
};
// Legacy default-scheme lookups, kept so existing references keep working
const SEX_COLOR = SEX_COLOR_SCHEMES.neutral;
const SEX_GLOW  = {
  "Male":  "0 0 6px #4a9eda88, 0 0 12px #4a9eda44",
  "Female":"0 0 6px #e05c7a88, 0 0 12px #e05c7a44",
};
const sexLabelFor = (sex, mode) => {
  if (!sex) return "";
  return mode==="symbol" ? (SEX_LABEL_SYMBOL[sex]||sex) : (SEX_LABEL_FULL[sex]||sex);
};
// Party letter shown alongside the sex when the partisan scheme is active
const SEX_PARTY_LETTER = { "Male":"D", "Female":"R" };

// Full display label, accounting for symbol mode and optional party letter
const sexDisplayFor = (sex, settings) => {
  if (!sex) return "";
  const base = sexLabelFor(sex, settings?.sexDisplayMode);
  const usePartisan = settings?.sexColorScheme === "partisan";
  if (usePartisan && settings?.showPartyLetter) {
    return `${SEX_PARTY_LETTER[sex]}·${base}`;
  }
  return base;
};

// ── Settings ─────────────────────────────────────────────────────────────────
const DEFAULT_SETTINGS = {
  sexDisplayMode: "full",      // "full" | "symbol"
  sexColorScheme: "neutral",   // "neutral" | "partisan"
  showPartyLetter: false,      // prefix badges with D-/R- when partisan
};
const SETTINGS_STORAGE_KEY = "chardb-settings";
const loadSettingsAsync = async () => {
  try {
    const r = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (r) return {...DEFAULT_SETTINGS, ...JSON.parse(r)};
  } catch (e) { /* key doesn't exist yet — use default */ }
  return {...DEFAULT_SETTINGS};
};
const saveSettingsAsync = async (s) => {
  try { localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(s)); }
  catch (e) { console.error("Failed to save settings:", e); }
};
const SettingsContext = React.createContext({ settings: DEFAULT_SETTINGS, setSettings: () => {} });
const useSettings = () => useContext(SettingsContext);

// ── Type affiliations (Pokémon-style) ─────────────────────────────────────────
const ALL_TYPES = [
  "Normal","Fire","Water","Electric","Grass","Ice","Fighting","Poison","Ground",
  "Flying","Psychic","Bug","Rock","Ghost","Dragon","Dark","Steel","Fairy",
  "Light","Sound",
];
const TYPE_COLOR = {
  Normal:"#9FA19F", Fire:"#FF8000", Water:"#2980EF", Electric:"#F7D02C",
  Grass:"#3FA129", Ice:"#3DCEF3", Fighting:"#C22E28", Poison:"#9141CB",
  Ground:"#D6A94A", Flying:"#81B9EF", Psychic:"#EF4179", Bug:"#91A119",
  Rock:"#B6A136", Ghost:"#704170", Dragon:"#5060E1", Dark:"#624D4E",
  Steel:"#60A1B8", Fairy:"#EF70EF",
  Light:"#40B5A5",  // teal-jade — luminous but distinct from the greens/blues
  Sound:"#68A090",  // muted sage-teal — resonant, sits near Light without clashing
};
const TYPE_LABEL = { Light:"Light (I/S)", Sound:"Sound (I/S)" };
const typeLabel = (t) => TYPE_LABEL[t] || t;
const typeGlow  = (t) => {
  const c = TYPE_COLOR[t]; if (!c) return "none";
  return `0 0 6px ${c}88, 0 0 12px ${c}44`;
};

// ── Position priority (lower = higher rank) ───────────────────────────────────
const INST_PRIORITY = {
  "Federal Monarchy":0,
  "State Monarchy":1,"Provincial Monarchy":1,
  "Federal Executive":2,
  "State Executive":3,"Provincial Executive":3,
  "Congress":4,
  "State Legislature":6,"Provincial Legislature":6,
  "Supreme Court":7,
  "State Judiciary":8,"Provincial Judiciary":8,
  "Armed Forces":9,
  "Federal Peerage":10,"State Peerage":10,"Provincial Peerage":10,
  "Federal Hereditary Knighthood":11,"State Hereditary Knighthood":11,"Provincial Hereditary Knighthood":11,
  "Federal Knightly Order":12,"State Knightly Order":12,"Provincial Knightly Order":12,
  "Federal Civil Honour":13,"State Civil Honour":13,"Provincial Civil Honour":13,
};

// Returns numeric priority score for a character (lowest among current positions wins)
const getTopScore = (char) => {
  const cur = (char.positions||[]).filter(p=>p.isCurrent);
  if (!cur.length) return 999;
  return Math.min(...cur.map(p => INST_PRIORITY[p.institutionType] ?? 998));
};

// Returns the single most senior current position for display
const getTopPosition = (char) => {
  const cur = (char.positions||[]).filter(p=>p.isCurrent);
  if (!cur.length) return null;
  return cur.reduce((best,p) =>
    (INST_PRIORITY[p.institutionType]??998) < (INST_PRIORITY[best.institutionType]??998) ? p : best
  );
};

// ── Persistence ───────────────────────────────────────────────────────────────

// Bump this whenever the top-level database shape changes in a way that needs
// migration logic (e.g. when the relational system between cards is introduced).
// Add version-specific upgrade steps inside migrateDatabase() as they're needed —
// this is the single place all future schema changes should route through.
const SCHEMA_VERSION = 1;

// Maps legacy institution type names onto their current names.
const LEGACY_INST_TYPE_MAP = {
  "Federal Legislature": "Congress",
  "Federal Regal Ministry": "Congress",
  "Federal Judiciary": "Supreme Court",
  "Federal Military": "Armed Forces",
};

// Maps legacy position title strings onto their current names.
const LEGACY_TITLE_MAP = {
  "Speaker of the Senate": "President of the Senate",
};

// Migrates a single legacy character record onto the current data model:
// - single `jurisdiction` field → realm (default primary, singular) +
//   additionalPrimary / secondary / tertiary (arrays, multiple allowed)
// - renamed institution types on any stored positions (e.g. "Federal Legislature" → "Congress")
// - renamed position titles (e.g. "Speaker of the Senate" → "President of the Senate")
// - renamed character-level `notes` field → `description` (position-level notes are unaffected)
// - utahLabradorRule: permission flag governing whether this character may take
//   part in a polygamous marriage (defaults off)
const migrateChar = (c) => ({
  ...c,
  realm: c.realm || c.jurisdiction || "",
  additionalPrimary: c.additionalPrimary || [],
  secondary: c.secondary || [],
  tertiary: c.tertiary || [],
  description: c.description || c.notes || "",
  utahLabradorRule: !!c.utahLabradorRule,
  positions: (c.positions||[]).map(p => ({
    ...p,
    institutionType: LEGACY_INST_TYPE_MAP[p.institutionType] || p.institutionType,
    title: LEGACY_TITLE_MAP[p.title] || p.title,
  })),
});

// Single entry point for normalizing ANY database blob — freshly loaded, imported
// from a file, or restored from a backup — onto the current schema. Every load,
// save, import, and export routes through this, so there is exactly one place
// to add logic when the schema changes (e.g. the future relational system between
// cards will live in the reserved `relationships` array below).
const migrateDatabase = (raw) => {
  if (!raw || typeof raw !== "object") {
    return { schemaVersion: SCHEMA_VERSION, chars:[], nextId:1, relationships:[], pairings:[], savedAt:null };
  }
  const chars = (raw.chars||[]).map(migrateChar);
  // Future schema-version-specific upgrade branches go here, keyed on raw.schemaVersion.
  return {
    schemaVersion: SCHEMA_VERSION,
    chars,
    nextId: raw.nextId || (chars.reduce((m,c)=>Math.max(m,c.id||0),0)+1),
    relationships: raw.relationships || [],
    // Romantic pairings — unordered binary links, no rank or precedence field by
    // design: every partner in a marriage stands at equal parity.
    pairings: raw.pairings || [],
    savedAt: raw.savedAt || null,
  };
};

const STORAGE_KEY = "chardb-data";
const loadChars = async () => {
  try {
    const r = localStorage.getItem(STORAGE_KEY);
    if (r) return migrateDatabase(JSON.parse(r));
  } catch (e) { /* key doesn't exist yet — use default */ }
  return migrateDatabase(null);
};
const saveChars = async (d) => {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(d)); }
  catch (e) { console.error("Failed to save character data:", e); }
};
const uid  = () => Math.random().toString(36).slice(2,9);

// ── IndexedDB handle store ──────────────────────────────────────────────────
// Persists FileSystemFileHandle references (main save file / backup file) across
// reloads, where the browser supports the File System Access API. This is what
// lets "Save" overwrite the same file every time instead of downloading a new
// one — no more piles of timestamped exports.
const IDB_NAME = "registry-fs-handles";
const IDB_STORE = "handles";
const idbOpen = () => new Promise((resolve, reject) => {
  const req = indexedDB.open(IDB_NAME, 1);
  req.onupgradeneeded = () => req.result.createObjectStore(IDB_STORE);
  req.onsuccess = () => resolve(req.result);
  req.onerror = () => reject(req.error);
});
const idbGet = async (key) => {
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, "readonly");
    const req = tx.objectStore(IDB_STORE).get(key);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
};
const idbSet = async (key, value) => {
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, "readwrite");
    tx.objectStore(IDB_STORE).put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
};
const idbDelete = async (key) => {
  const db = await idbOpen();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IDB_STORE, "readwrite");
    tx.objectStore(IDB_STORE).delete(key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
};

// Returns every jurisdiction assigned to a character, across all four tiers
const allJurisdictionsOf = (c) => [
  c.realm, ...(c.additionalPrimary||[]), ...(c.secondary||[]), ...(c.tertiary||[]),
].filter(Boolean);

// ── Sub-components ────────────────────────────────────────────────────────────

const Badge = ({label, color="#888", glow}) => (
  <span style={{
    display:"inline-block", padding:"2px 7px", borderRadius:"3px",
    fontSize:"10px", fontWeight:700, letterSpacing:"0.07em",
    background:color+"22", color, border:`1px solid ${color}44`,
    fontFamily:"'Courier Prime',monospace", textTransform:"uppercase", whiteSpace:"nowrap",
    boxShadow: glow||"none",
  }}>{label}</span>
);

const Inp = ({label, children}) => (
  <label style={{display:"block"}}>
    {label && <span style={{display:"block",fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:"4px"}}>{label}</span>}
    {children}
  </label>
);

const inputStyle = {
  background:"#080c11", border:"1px solid #1a2535", color:"#c8d8e8",
  borderRadius:"4px", padding:"7px 10px", fontSize:"12px",
  fontFamily:"'Courier Prime',monospace", width:"100%",
};

// ── JurisdictionTagList ──────────────────────────────────────────────────────
// Multi-select tag list for Additional Primary / Secondary / Tertiary jurisdictions.
// `usedElsewhere` excludes jurisdictions already claimed by this character in
// any tier (including its own), so the same state/province can't be double-assigned.
function JurisdictionTagList({label, values, onChange, usedElsewhere, accentColor="#5aa4d0"}) {
  const available = ALL_JURISDICTIONS.filter(j => !usedElsewhere.includes(j));
  const add = (j) => { if (!j) return; onChange([...values, j]); };
  const remove = (j) => onChange(values.filter(x=>x!==j));

  return (
    <div>
      <Inp label={label}>
        <select value="" onChange={e=>add(e.target.value)} style={inputStyle}>
          <option value="">— add jurisdiction —</option>
          <optgroup label="US States">
            {JURISDICTIONS_US.filter(j=>available.includes(j)).map(j=><option key={j}>{j}</option>)}
          </optgroup>
          <optgroup label="Canadian Provinces">
            {JURISDICTIONS_CA.filter(j=>available.includes(j)).map(j=><option key={j}>{j}</option>)}
          </optgroup>
        </select>
      </Inp>
      {values.length>0 && (
        <div style={{display:"flex",flexWrap:"wrap",gap:"5px",marginTop:"7px"}}>
          {values.map(j=>(
            <span key={j} style={{
              display:"inline-flex",alignItems:"center",gap:"5px",
              padding:"3px 8px",borderRadius:"3px",fontSize:"11px",
              background:accentColor+"1a",color:accentColor,border:`1px solid ${accentColor}44`,
              fontFamily:"'Courier Prime',monospace",
            }}>
              {j}
              <button onClick={()=>remove(j)} style={{
                background:"none",border:"none",color:accentColor,cursor:"pointer",
                fontSize:"11px",lineHeight:1,padding:0,opacity:0.7,
              }}>✕</button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

function PositionPill({pos}) {
  const isMonarchy   = pos.institutionType?.includes("Monarchy");
  const isPeerage    = pos.institutionType?.includes("Peerage");
  const isHeredKt    = pos.institutionType?.includes("Hereditary Knighthood");
  const isKnightOrd  = pos.institutionType?.includes("Knightly Order");
  const isCivilHon   = pos.institutionType?.includes("Civil Honour");
  const isHonour     = isHeredKt || isKnightOrd || isCivilHon;
  return (
    <div style={{
      display:"flex",alignItems:"flex-start",gap:"8px",
      background:"#09101a",border:"1px solid #182030",
      borderLeft:`3px solid ${col(pos.institutionType)}`,
      borderRadius:"4px",padding:"7px 10px",
    }}>
      <span style={{fontSize:"13px",flexShrink:0,marginTop:"1px"}}>{ico(pos.institutionType)}</span>
      <div style={{flex:1,minWidth:0}}>
        <div style={{display:"flex",gap:"5px",flexWrap:"wrap",alignItems:"center"}}>
          <span style={{fontWeight:700,fontSize:"12px",color:"#ddd0b8"}}>{pos.title}</span>
          <Badge label={pos.institutionType} color={col(pos.institutionType)}/>
          <Badge label={pos.isCurrent?"Current":"Former"} color={pos.isCurrent?"#4caf82":"#556"}/>
          {isMonarchy  && <Badge label="Style of Majesty" color="#c9a84c"/>}
          {isPeerage   && <Badge label="Lord of the Estate" color="#c46a8a"/>}
          {isHeredKt   && <Badge label="Hereditary" color="#b0a080"/>}
          {isKnightOrd && <Badge label="Non-Hereditary" color="#80a0b8"/>}
          {isCivilHon  && <Badge label="Civil Honour" color="#8aaa60"/>}
          {pos.rank && gradeFor(pos.branch, pos.rank) && (
            <Badge
              label={gradeFor(pos.branch, pos.rank)}
              color={MIL_ELEVATED_GRADES.has(gradeFor(pos.branch, pos.rank)) ? "#c9a84c" : "#6a8a9a"}
              glow={MIL_ELEVATED_GRADES.has(gradeFor(pos.branch, pos.rank)) ? "0 0 6px #c9a84c88, 0 0 12px #c9a84c44" : undefined}
            />
          )}
        </div>
        {isPeerage && (
          <div style={{fontSize:"10px",color:"#7a4a5a",marginTop:"3px",fontFamily:"'Courier Prime',monospace"}}>
            Alt. address: Lord [Name]{pos.title&&(pos.title==="Duke"||pos.title==="Marquess"||pos.title==="Earl"||pos.title==="Viscount"||pos.title==="Baron") ? " · Gent [Name]" : pos.title&&(pos.title==="Duchess"||pos.title==="Marchioness"||pos.title==="Countess"||pos.title==="Viscountess"||pos.title==="Baroness") ? " · Lady [Name]" : ""}
          </div>
        )}
        {isHonour && pos.grantingAuthority && (
          <div style={{fontSize:"11px",color:"#708060",marginTop:"2px"}}>
            Granted by: {pos.grantingAuthority}
          </div>
        )}
        {isHonour && pos.orderName && (
          <div style={{fontSize:"11px",color:"#708090",marginTop:"2px"}}>
            Order / Award: {pos.orderName}
          </div>
        )}
        {pos.house && <div style={{fontSize:"11px",color:"#c9a84c",marginTop:"2px"}}>⌂ House: {pos.house}</div>}
        {pos.jurisdiction && <div style={{fontSize:"11px",color:"#506070",marginTop:"2px"}}>Jurisdiction: {pos.jurisdiction}</div>}
        {pos.estateName && <div style={{fontSize:"11px",color:"#9a5070",marginTop:"2px"}}>Estate: {pos.estateName}</div>}
        {pos.peerageProcess && <div style={{fontSize:"11px",color:"#c46a8a",marginTop:"2px"}}>❦ {pos.peerageProcess}</div>}
        {(pos.startYear||pos.endYear) && (
          <div style={{fontSize:"11px",color:"#404e5c",marginTop:"2px"}}>
            {pos.startYear||"?"} – {pos.isCurrent?"present":(pos.endYear||"?")}
          </div>
        )}
        {pos.notes && <div style={{fontSize:"11px",color:"#607080",fontStyle:"italic",marginTop:"2px"}}>{pos.notes}</div>}
      </div>
    </div>
  );
}

function AddPositionForm({onAdd, onCancel}) {
  const [inst,setInst]   = useState("Federal Executive");
  const [title,setTitle] = useState("");
  const [branch,setBranch] = useState("Army");
  const [rank,setRank]   = useState(MIL_RANKS_BY_BRANCH["Army"][0]);
  const [jur,setJur]     = useState("");
  const [sy,setSy]       = useState(""); const [ey,setEy] = useState("");
  const [cur,setCur]     = useState(true);
  const [notes,setNotes] = useState("");
  const [custom,setCustom] = useState("");
  // Peerage-specific
  const [estateName,setEstateName]         = useState("");
  const [peerageProcess,setPeerageProcess] = useState("");
  // Honours-specific
  const [orderName,setOrderName]             = useState("");
  const [grantingAuthority,setGrantingAuth] = useState("");
  // Monarchy & Peerage — dynastic house
  const [house,setHouse]                     = useState("");

  const isMil      = inst === "Armed Forces";
  const isMonarchy = inst.includes("Monarchy");
  const isSubMon   = inst === "State Monarchy" || inst === "Provincial Monarchy";
  const isCongress = inst === "Congress";
  const isPeerage  = inst.includes("Peerage");
  const isHeredKt  = inst.includes("Hereditary Knighthood");
  const isKnightOrd= inst.includes("Knightly Order");
  const isCivilHon = inst.includes("Civil Honour");
  const isHonour   = isHeredKt || isKnightOrd || isCivilHon;
  // Houses apply to the two hereditary hierarchies: Lords Sovereign (monarchy)
  // and Lords of the Estates (peerage). Hereditary knighthoods are hereditary
  // too, so they get the field as well.
  const needsHouse = isMonarchy || isPeerage || isHeredKt;
  const needJur    = inst.startsWith("State") || inst.startsWith("Provincial");
  const basePositions = INST_POSITIONS[inst] || [];
  // For sub-national monarchies, prepend the jurisdiction-specific sovereign titles
  const sovereignOptions = isSubMon && jur
    ? getSovereignTitles(jur)
    : [];
  const positions = isSubMon
    ? [...sovereignOptions, ...basePositions]
    : basePositions;
  const jurList = needJur
    ? (inst.startsWith("State") ? JURISDICTIONS_US : JURISDICTIONS_CA)
    : [];
  const branchRanks = MIL_RANKS_BY_BRANCH[branch] || [];
  // sovereignty info badge for sub-national monarchies
  const sovType = isSubMon && jur ? SOVEREIGNTY_MAP[jur] : null;

  const handleBranchChange = (b) => {
    setBranch(b);
    setRank(MIL_RANKS_BY_BRANCH[b]?.[0] || "");
  };

  const submit = () => {
    const resolvedTitle = isMil ? `${rank} · ${branch}` : (title==="__custom__" ? custom : title);
    if (!resolvedTitle) return;
    onAdd({
      id:uid(), institutionType:inst,
      title:resolvedTitle,
      branch: isMil?branch:undefined,
      rank:   isMil?rank:undefined,
      jurisdiction: needJur?jur:undefined,
      estateName:      isPeerage?(estateName||undefined):undefined,
      peerageProcess:  isPeerage?(peerageProcess||undefined):undefined,
      orderName:       isHonour?(orderName||undefined):undefined,
      grantingAuthority: isHonour?(grantingAuthority||undefined):undefined,
      house:           needsHouse?(house||undefined):undefined,
      startYear:sy||undefined,
      endYear:cur?undefined:(ey||undefined),
      isCurrent:cur, notes:notes||undefined,
    });
  };

  return (
    <div style={{background:"#09101a",border:"1px solid #1e2d3e",borderRadius:"6px",padding:"14px",marginTop:"8px"}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"10px"}}>
        <div style={{gridColumn:"1/-1"}}>
          <Inp label="Institution Type">
            <select value={inst} onChange={e=>{setInst(e.target.value);setTitle("");setJur("");setPeerageProcess("");setOrderName("");setGrantingAuth("");setHouse("");}} style={inputStyle}>
              {INSTITUTION_TYPES.map(t=><option key={t}>{t}</option>)}
            </select>
          </Inp>
        </div>

        {isMil ? (<>
          <Inp label="Branch">
            <select value={branch} onChange={e=>handleBranchChange(e.target.value)} style={inputStyle}>
              {MIL_BRANCHES.map(b=><option key={b}>{b}</option>)}
            </select>
          </Inp>
          <Inp label="Rank">
            <select value={rank} onChange={e=>setRank(e.target.value)}
              style={{...inputStyle,
                color: MIL_ELEVATED_GRADES.has(gradeFor(branch,rank)) ? "#c9a84c" : inputStyle.color,
                fontWeight: MIL_ELEVATED_GRADES.has(gradeFor(branch,rank)) ? 700 : 400}}>
              {branchRanks.map(r=>{
                const g = gradeFor(branch, r);
                return <option key={r} value={r}>{g ? `${g} — ${r}` : r}</option>;
              })}
            </select>
          </Inp>
          {MIL_ELEVATED_GRADES.has(gradeFor(branch,rank)) && (
            <div style={{gridColumn:"1/-1",fontSize:"11px",color:"#c9a84c",fontFamily:"'Courier Prime',monospace",padding:"6px 10px",background:"#14120a",border:"1px solid #2a2810",borderRadius:"4px",lineHeight:1.5}}>
              ★ {gradeFor(branch,rank)} — {MIL_GRADE_NOTE[gradeFor(branch,rank)]}
            </div>
          )}
        </>) : (<>
          {/* For sub-national monarchies, jurisdiction must come FIRST so titles populate */}
          {isSubMon && (
            <div style={{gridColumn:"1/-1"}}>
              <Inp label={inst.startsWith("State") ? "State" : "Province"}>
                <select value={jur} onChange={e=>{setJur(e.target.value);setTitle("");}} style={inputStyle}>
                  <option value="">— select jurisdiction first —</option>
                  {jurList.map(j=><option key={j}>{j}</option>)}
                </select>
              </Inp>
              {sovType && (
                <div style={{marginTop:"5px",fontSize:"11px",color:"#c9a84c",fontFamily:"'Courier Prime',monospace"}}>
                  ♛ {jur} is a <strong>{sovType}</strong> · Style: <em>Majesty</em>
                </div>
              )}
            </div>
          )}
          <div style={{gridColumn:"1/-1"}}>
            <Inp label="Position / Title">
              <select value={title} onChange={e=>setTitle(e.target.value)} style={inputStyle}
                disabled={isSubMon && !jur}>
                <option value="">{isSubMon && !jur ? "— select jurisdiction first —" : "— select —"}</option>
                {sovereignOptions.length > 0 && (
                  <optgroup label={`── Sovereign of the ${sovType} ──`}>
                    {sovereignOptions.map(p=><option key={p}>{p}</option>)}
                  </optgroup>
                )}
                {isCongress ? (
                  CONGRESS_CHAMBERS.map(ch=>(
                    <optgroup key={ch.label} label={`── ${ch.label} ──`}>
                      {ch.positions.map(p=><option key={p}>{p}</option>)}
                    </optgroup>
                  ))
                ) : basePositions.length > 0 && (
                  <optgroup label="── Court & Noble Positions ──">
                    {basePositions.map(p=><option key={p}>{p}</option>)}
                  </optgroup>
                )}
                <option value="__custom__">Custom…</option>
              </select>
            </Inp>
            {title==="__custom__" && (
              <input value={custom} onChange={e=>setCustom(e.target.value)}
                placeholder="Enter custom title…" style={{...inputStyle,marginTop:"6px"}}/>
            )}
          </div>
        </>)}

        {/* Jurisdiction picker for non-monarchy sub-national institutions */}
        {needJur && !isSubMon && (
          <div style={{gridColumn:"1/-1"}}>
            <Inp label={inst.startsWith("State")?"State":"Province"}>
              <select value={jur} onChange={e=>setJur(e.target.value)} style={inputStyle}>
                <option value="">— select —</option>
                {jurList.map(j=><option key={j}>{j}</option>)}
              </select>
            </Inp>
          </div>
        )}

        {/* House — dynastic affiliation, for the hereditary hierarchies */}
        {needsHouse && (
          <div style={{gridColumn:"1/-1"}}>
            <Inp label="House (dynastic affiliation)">
              <input value={house} onChange={e=>setHouse(e.target.value)}
                placeholder="e.g. House of Ashford, Windsor…" style={inputStyle}/>
            </Inp>
          </div>
        )}

        {/* Peerage-specific fields */}
        {isPeerage && (<>
          <div style={{gridColumn:"1/-1"}}>
            <Inp label="Estate / Territory Name">
              <input value={estateName} onChange={e=>setEstateName(e.target.value)}
                placeholder="e.g. Duke of Albany, Baron of Redstone…" style={inputStyle}/>
            </Inp>
          </div>
          <div style={{gridColumn:"1/-1"}}>
            <Inp label="Ennoblement Process">
              <select value={peerageProcess} onChange={e=>setPeerageProcess(e.target.value)} style={inputStyle}>
                <option value="">— select —</option>
                <option value="Patriated">Patriated — imperial creation, patriated by Lord Sovereign</option>
                <option value="Mediatized">Mediatized — sub-national creation, mediatized by Emperor</option>
                <option value="Pending Patriation">Pending Patriation</option>
                <option value="Pending Mediatization">Pending Mediatization</option>
              </select>
            </Inp>
          </div>
          {peerageProcess && (
            <div style={{gridColumn:"1/-1",fontSize:"11px",color:"#c46a8a",fontFamily:"'Courier Prime',monospace",padding:"6px 10px",background:"#1a0a12",border:"1px solid #3a1a2a",borderRadius:"4px"}}>
              {peerageProcess==="Patriated" && "❦ Imperial creation — ennoblement takes effect upon patriation by the relevant Lord Sovereign."}
              {peerageProcess==="Mediatized" && "❦ Sub-national creation — ennoblement takes effect upon mediatization by the Emperor."}
              {peerageProcess==="Pending Patriation" && "⏳ Awaiting patriation by the Lord Sovereign before ennoblement is effective."}
              {peerageProcess==="Pending Mediatization" && "⏳ Awaiting mediatization by the Emperor before ennoblement is effective."}
            </div>
          )}
        </>)}

        {/* Honours-specific fields */}
        {isHonour && (<>
          <div style={{gridColumn:"1/-1"}}>
            <Inp label={isHeredKt ? "Hereditary Knighthood Variant" : isKnightOrd ? "Order Name" : "Award Name"}>
              <input value={orderName} onChange={e=>setOrderName(e.target.value)}
                placeholder={
                  isHeredKt  ? "e.g. Baronetcy of Redstone (variant TBD)…" :
                  isKnightOrd? "e.g. Order of the Golden Eagle…" :
                               "e.g. Presidential Medal of Freedom…"
                }
                style={inputStyle}/>
            </Inp>
          </div>
          <div style={{gridColumn:"1/-1"}}>
            <Inp label="Granting Authority">
              <input value={grantingAuthority} onChange={e=>setGrantingAuth(e.target.value)}
                placeholder={
                  isHeredKt  ? "e.g. Emperor / King of Texas (Lord Sovereign)…" :
                  isKnightOrd? "e.g. Emperor (sovereign of order) / Queen of Ohio…" :
                               "e.g. President / Governor of California…"
                }
                style={inputStyle}/>
            </Inp>
          </div>
          {isHeredKt && (
            <div style={{gridColumn:"1/-1",fontSize:"11px",color:"#b0a080",fontFamily:"'Courier Prime',monospace",padding:"6px 10px",background:"#14120a",border:"1px solid #2a2810",borderRadius:"4px"}}>
              ✠ Hereditary knighthood — regional variant (Baronet / Hidalgo / Ritter) to be assigned per jurisdiction. Male: Sir. Female: Dame. Created by Lord Sovereign or patriated from federal grant.
            </div>
          )}
          {isKnightOrd && (
            <div style={{gridColumn:"1/-1",fontSize:"11px",color:"#80a0b8",fontFamily:"'Courier Prime',monospace",padding:"6px 10px",background:"#0a1018",border:"1px solid #101828",borderRadius:"4px"}}>
              ✙ Knightly order — non-hereditary. Granting authority is the sovereign of the order. Male: Sir. Female: Dame.
            </div>
          )}
          {isCivilHon && (
            <div style={{gridColumn:"1/-1",fontSize:"11px",color:"#8aaa60",fontFamily:"'Courier Prime',monospace",padding:"6px 10px",background:"#0a1208",border:"1px solid #182010",borderRadius:"4px"}}>
              ★ Civil honour — granted by head of government (President, Governor, Premier). Personal and non-hereditary. No titular prefix.
            </div>
          )}
        </>)}

        <Inp label="Start Year">
          <input type="number" placeholder="e.g. 2020" value={sy}
            onChange={e=>setSy(e.target.value)} style={inputStyle}/>
        </Inp>
        <Inp label="End Year">
          <input type="number" placeholder="e.g. 2024" value={ey}
            onChange={e=>setEy(e.target.value)} style={inputStyle} disabled={cur}/>
        </Inp>

        <div style={{gridColumn:"1/-1",display:"flex",alignItems:"center",gap:"8px"}}>
          <input type="checkbox" id="curPos" checked={cur} onChange={e=>setCur(e.target.checked)} style={{accentColor:"#4caf82"}}/>
          <label htmlFor="curPos" style={{fontSize:"12px",color:"#8a9aaa",fontFamily:"'Courier Prime',monospace",cursor:"pointer"}}>
            Currently holds this position
          </label>
        </div>

        <div style={{gridColumn:"1/-1"}}>
          <Inp label="Notes">
            <input value={notes} onChange={e=>setNotes(e.target.value)}
              placeholder="Optional notes…" style={inputStyle}/>
          </Inp>
        </div>
      </div>

      <div style={{display:"flex",gap:"8px",marginTop:"12px"}}>
        <button onClick={submit} style={{background:"#0e2018",border:"1px solid #2a5a3a",color:"#5caf78",borderRadius:"4px",padding:"6px 14px",cursor:"pointer",fontSize:"12px",fontFamily:"'Courier Prime',monospace",fontWeight:700}}>
          + Add Position
        </button>
        <button onClick={onCancel} style={{background:"none",border:"1px solid #1e2d3e",color:"#506070",borderRadius:"4px",padding:"6px 14px",cursor:"pointer",fontSize:"12px",fontFamily:"'Courier Prime',monospace"}}>
          Cancel
        </button>
      </div>
    </div>
  );
}

// ── RelationsSection ──────────────────────────────────────────────────────────
// Relations are always binary, stored once at the database's top level regardless
// of which character's modal created them. A single relation carries three factors:
// the nature of the relationship (what the two are, together), and each side's own
// role within it (what A is to B, and what B is to A). Two characters can hold any
// number of distinct relations with each other (e.g. siblings AND senpai/kouhai).
//
// The "other character" is entered as freeform text, not picked from a dropdown —
// this is an abstract, user-defined concept, not a constrained lookup. If the typed
// name matches an existing character exactly, the relation links to that character's
// id (so it stays in sync if they're renamed, and shows up on their card too). If it
// doesn't match anyone yet, the typed name is kept as-is — nothing stops you from
// describing a relation before both cards exist.
// ── PairingSection ────────────────────────────────────────────────────────────
// Romantic pairings between one male and one female character. Pairings are
// unordered binary links with no rank or precedence field — every partner in a
// marriage stands at equal parity, and partners are listed alphabetically so
// insertion order never implies seniority.
//
// The "Utah-Labrador rule" is a permission flag, not a status. It governs what a
// character is ALLOWED to do; the actual monogamous/polygamous status is derived
// from how many pairings they actually hold. A wife with one husband displays as
// an ordinary couple even with the rule enabled.
const PAIRING_ACCENT = "#d98aa8";

function PairingSection({thisChar, isNew, allChars, pairings, onAddPairing, onRemovePairing, formRule, onFormRuleChange}) {
  const { settings } = useSettings();
  const [partnerName, setPartnerName] = useState("");
  const [error, setError] = useState("");

  const sectionLabel = {
    fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",
    letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:"10px",
  };

  if (isNew || !thisChar) {
    return (
      <div style={{borderTop:"1px solid #131e2b",paddingTop:"12px",marginTop:"2px"}}>
        <div style={sectionLabel}>Romantic Pairing</div>
        <div style={{fontSize:"11px",color:"#4a5a6a",fontStyle:"italic"}}>
          Save this character first before adding a pairing.
        </div>
      </div>
    );
  }

  const myId = thisChar.id;
  const charById = (id) => allChars.find(c=>c.id===id);
  const myPairings = pairings.filter(p => p.a===myId || p.b===myId);
  const partnerIdsOf = (charId) =>
    pairings.filter(p=>p.a===charId||p.b===charId).map(p=>p.a===charId?p.b:p.a);

  // Alphabetical, so insertion order never reads as precedence
  const partners = myPairings
    .map(p => ({ pairing:p, partner: charById(p.a===myId ? p.b : p.a) }))
    .filter(x => x.partner)
    .sort((x,y) => (x.partner.name||"").localeCompare(y.partner.name||""));

  const isPolygamous = partners.length > 1;

  const submit = () => {
    setError("");
    const name = partnerName.trim();
    if (!name) return;

    if (!thisChar.sex) { setError("Set this character's sex before pairing."); return; }

    const match = allChars.find(c => c.id!==myId && (c.name||"").trim().toLowerCase()===name.toLowerCase());
    if (!match) { setError(`No character named "${name}" exists yet.`); return; }
    if (!match.sex) { setError(`${match.name} has no sex set.`); return; }
    if (match.sex === thisChar.sex) { setError("Pairings must be between one male and one female character."); return; }
    if (partners.some(p => p.partner.id === match.id)) { setError(`Already paired with ${match.name}.`); return; }

    // Utah-Labrador rule gate — checked against the live form value for this
    // character, so enabling the toggle takes effect before saving.
    // A pairing becomes polygamous if EITHER side already holds one; in that
    // case BOTH sides must have the rule enabled, including the person joining
    // an existing marriage who currently has no pairings of their own.
    const myCount = partners.length;
    const theirCount = partnerIdsOf(match.id).length;
    const wouldBePolygamous = myCount >= 1 || theirCount >= 1;
    if (wouldBePolygamous) {
      const missing = [];
      if (!formRule) missing.push(thisChar.name);
      if (!match.utahLabradorRule) missing.push(match.name);
      if (missing.length) {
        setError(
          missing.length === 1
            ? `${missing[0]} needs the Utah-Labrador rule enabled for a polygamous pairing.`
            : `Both ${missing[0]} and ${missing[1]} need the Utah-Labrador rule enabled.`
        );
        return;
      }
    }

    onAddPairing(myId, match.id);
    setPartnerName("");
  };

  // Blocking the toggle off while multiple pairings exist keeps the data coherent
  const tryToggleRule = (next) => {
    setError("");
    if (!next && partners.length > 1) {
      setError("Remove additional spouses before disabling the Utah-Labrador rule.");
      return;
    }
    onFormRuleChange(next);
  };

  return (
    <div style={{borderTop:"1px solid #131e2b",paddingTop:"12px",marginTop:"2px"}}>
      <div style={sectionLabel}>
        Romantic Pairing{partners.length>0?` (${partners.length})`:""}
      </div>

      {/* Current pairing(s) — equal parity, alphabetical, no ranking */}
      {partners.length > 0 && (
        <div style={{marginBottom:"12px"}}>
          <div style={{fontSize:"13px",color:"#ddd0b8",lineHeight:1.45}}>
            <span style={{color:PAIRING_ACCENT}}>♥ </span>
            Paired with{" "}
            {partners.map((x,i) => {
              // Name glows in the partner's primary type colour; falls back to the
              // default text colour when no Type 1 is set.
              const nameColor = x.partner.type1 ? TYPE_COLOR[x.partner.type1] : "#ddd0b8";
              const nameGlow  = x.partner.type1 ? typeGlow(x.partner.type1) : "none";
              // Symbol glows in the partner's sex colour, honouring the current scheme.
              const symColor  = sexColorFor(x.partner.sex, settings.sexColorScheme);
              const symGlow   = sexGlowFor(x.partner.sex, settings.sexColorScheme);
              return (
                <span key={x.pairing.id}>
                  <span
                    onClick={()=>onRemovePairing(x.pairing.id)}
                    title="Click to remove this pairing"
                    style={{cursor:"pointer",borderBottom:`1px dotted ${PAIRING_ACCENT}55`,fontWeight:700}}
                  >
                    <span style={{color:nameColor,textShadow:nameGlow}}>{x.partner.name}</span>
                    {x.partner.sex && (
                      <span style={{color:symColor,textShadow:symGlow}}>
                        {SEX_LABEL_SYMBOL[x.partner.sex]}
                      </span>
                    )}
                  </span>
                  {i < partners.length-2 ? ", " : i === partners.length-2 ? (partners.length>2 ? ", and " : " and ") : ""}
                </span>
              );
            })}
          </div>
          {isPolygamous && (
            <div style={{fontSize:"10px",color:"#7a5a68",marginTop:"3px",fontFamily:"'Courier Prime',monospace"}}>
              Polygamous marriage — all partners at equal parity
            </div>
          )}
        </div>
      )}

      {/* Utah-Labrador rule toggle */}
      <label style={{
        display:"flex",alignItems:"flex-start",gap:"9px",padding:"9px 11px",marginBottom:"10px",
        background: formRule ? "#1a1016" : "#080c11",
        border:`1px solid ${formRule?"#4a2a38":"#131e2b"}`,
        borderRadius:"5px",cursor:"pointer",
      }}>
        <input type="checkbox" checked={!!formRule}
          onChange={e=>tryToggleRule(e.target.checked)}
          style={{accentColor:PAIRING_ACCENT,marginTop:"1px"}}/>
        <span style={{flex:1,minWidth:0}}>
          <span style={{display:"block",fontSize:"12px",fontWeight:700,color:formRule?"#e8b8c8":"#8a9aaa",fontFamily:"'Courier Prime',monospace"}}>
            Utah-Labrador rule
          </span>
          <span style={{display:"block",fontSize:"10px",color:"#5a6a7a",marginTop:"2px",lineHeight:1.45}}>
            Permits this character to take part in a polygamous marriage. Both sides
            must have it enabled. Does not by itself make them polygamous.
          </span>
        </span>
      </label>

      {/* Add pairing */}
      <div style={{background:"#09101a",border:"1px solid #1e2d3e",borderRadius:"6px",padding:"12px"}}>
        <Inp label="Pair With (typed, not selected)">
          <input value={partnerName} onChange={e=>{setPartnerName(e.target.value);setError("");}}
            onKeyDown={e=>{if(e.key==="Enter"){e.preventDefault();submit();}}}
            placeholder="Type the other character's name…" style={inputStyle}/>
        </Inp>
        {error && (
          <div style={{fontSize:"11px",color:"#e08080",marginTop:"7px",fontFamily:"'Courier Prime',monospace",lineHeight:1.45}}>
            {error}
          </div>
        )}
        <button onClick={submit} style={{
          marginTop:"10px",background:"#1a1016",border:`1px solid ${PAIRING_ACCENT}66`,color:PAIRING_ACCENT,
          borderRadius:"4px",padding:"7px 14px",cursor:"pointer",
          fontSize:"12px",fontFamily:"'Courier Prime',monospace",fontWeight:700,
        }}>♥ Add Pairing</button>
      </div>
    </div>
  );
}

const RELATION_ACCENT = "#8ca0c4";

const joinCommas = (arr) => arr.join(", ");
const joinWithAnd = (arr) => {
  if (arr.length === 0) return "";
  if (arr.length === 1) return arr[0];
  if (arr.length === 2) return `${arr[0]} and ${arr[1]}`;
  return `${arr.slice(0,-1).join(", ")}, and ${arr[arr.length-1]}`;
};

function RelationsSection({thisChar, isNew, allChars, relationships, onAddRelation, onRemoveRelation}) {
  const [otherName, setOtherName] = useState("");
  const [nature, setNature]       = useState("");
  const [roleA, setRoleA]         = useState(""); // what thisChar is to the other
  const [roleB, setRoleB]         = useState(""); // what the other is to thisChar

  const sectionLabel = {
    fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",
    letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:"10px",
  };

  if (isNew || !thisChar) {
    return (
      <div style={{borderTop:"1px solid #131e2b",paddingTop:"12px",marginTop:"2px"}}>
        <div style={sectionLabel}>Relations</div>
        <div style={{fontSize:"11px",color:"#4a5a6a",fontStyle:"italic"}}>
          Save this character first before adding relations.
        </div>
      </div>
    );
  }

  const myId = thisChar.id;
  const nameOfId = (id) => allChars.find(c=>c.id===id)?.name || "Unknown";
  const myRelations = relationships.filter(r => r.charA===myId || r.charB===myId);

  // Resolve each relation to this character's viewpoint: the partner's role
  // toward this character (shown next to their name), the nature, and a
  // display name + grouping key for the other party (by id when linked,
  // otherwise by the raw typed name).
  const resolved = myRelations.map(r => {
    const isA = r.charA === myId;
    const otherIdRaw = isA ? r.charB : r.charA;
    const displayName = (otherIdRaw!=null) ? nameOfId(otherIdRaw) : (r.otherName || "Unknown");
    const key = (otherIdRaw!=null) ? `id:${otherIdRaw}` : `name:${displayName.toLowerCase()}`;
    return {
      relation: r,
      theirRole: isA ? r.roleB : r.roleA, // what the OTHER character is to THIS one
      nature: r.nature,
      displayName,
      key,
    };
  });

  // Group by partner
  const groups = {};
  resolved.forEach(item => {
    if (!groups[item.key]) groups[item.key] = { displayName: item.displayName, items: [] };
    groups[item.key].items.push(item);
  });
  const groupList = Object.values(groups).sort((a,b)=>a.displayName.localeCompare(b.displayName));

  const submit = () => {
    if (!otherName.trim() || !nature.trim()) return;
    const match = allChars.find(c => c.id!==myId && c.name.trim().toLowerCase()===otherName.trim().toLowerCase());
    onAddRelation(myId, match ? match.id : null, otherName.trim(), nature.trim(), roleA.trim(), roleB.trim());
    setOtherName(""); setNature(""); setRoleA(""); setRoleB("");
  };

  return (
    <div style={{borderTop:"1px solid #131e2b",paddingTop:"12px",marginTop:"2px"}}>
      <div style={sectionLabel}>Relations{myRelations.length>0?` (${myRelations.length})`:""}</div>

      {groupList.length > 0 && (
        <div style={{display:"flex",flexDirection:"column",gap:"11px",marginBottom:"14px"}}>
          {groupList.map(group => (
            <div key={group.displayName}>
              <div style={{fontSize:"13px",fontWeight:700,color:"#ddd0b8",lineHeight:1.3}}>
                {group.displayName}{" "}
                <span style={{color:"#7a8a9a",fontWeight:400,fontSize:"11px"}}>
                  ({joinCommas(group.items.map(it=>it.theirRole||"—"))})
                </span>
              </div>
              <div style={{fontSize:"10px",color:"#4a5a6a",marginTop:"2px",letterSpacing:"0.02em",lineHeight:1.4}}>
                {group.items.map((it,i) => (
                  <span key={it.relation.id}>
                    <span
                      onClick={()=>onRemoveRelation(it.relation.id)}
                      title="Click to remove this relation"
                      style={{cursor:"pointer",borderBottom:"1px dotted #2a3a4a"}}
                    >{it.nature}</span>
                    {i < group.items.length-2 ? ", " : i === group.items.length-2 ? (group.items.length>2 ? ", and " : " and ") : ""}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <div style={{background:"#09101a",border:"1px solid #1e2d3e",borderRadius:"6px",padding:"12px"}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"10px"}}>
          <div style={{gridColumn:"1/-1"}}>
            <Inp label="Other Character (typed, not selected)">
              <input value={otherName} onChange={e=>setOtherName(e.target.value)}
                placeholder="Type the other character's name…" style={inputStyle}/>
            </Inp>
          </div>
          <div style={{gridColumn:"1/-1"}}>
            <Inp label="Nature of Relationship (what they are, together)">
              <input value={nature} onChange={e=>setNature(e.target.value)}
                placeholder="e.g. Siblings, Classmates, Rivals…" style={inputStyle}/>
            </Inp>
          </div>
          <Inp label={`${thisChar.name}'s Role (what they are to the other)`}>
            <input value={roleA} onChange={e=>setRoleA(e.target.value)}
              placeholder="e.g. Ani (兄), Senpai…" style={inputStyle}/>
          </Inp>
          <Inp label="Their Role (what the other is to this character)">
            <input value={roleB} onChange={e=>setRoleB(e.target.value)}
              placeholder="e.g. Otouto (弟), Kouhai…" style={inputStyle}/>
          </Inp>
        </div>
        <button onClick={submit} style={{
          marginTop:"10px",background:"#0e1a28",border:`1px solid ${RELATION_ACCENT}66`,color:RELATION_ACCENT,
          borderRadius:"4px",padding:"7px 14px",cursor:"pointer",
          fontSize:"12px",fontFamily:"'Courier Prime',monospace",fontWeight:700,
        }}>+ Add Relation</button>
      </div>
    </div>
  );
}

function CharModal({char, isNew, onSave, onDelete, onClose, allChars=[], relationships=[], onAddRelation, onRemoveRelation, pairings=[], onAddPairing, onRemovePairing}) {
  const { settings } = useSettings();
  const blank = {name:"",sex:"",realm:"",additionalPrimary:[],secondary:[],tertiary:[],source:"",designations:"",description:"",type1:"",type2:"",positions:[],utahLabradorRule:false};
  const [f,setF] = useState(char || blank);
  const [addPos, setAddPos] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const [activeTab, setActiveTab] = useState("identity");

  const set = (k,v) => setF(p=>({...p,[k]:v}));
  const curPositions = (f.positions||[]).filter(p=>p.isCurrent);
  const pastPositions = (f.positions||[]).filter(p=>!p.isCurrent);

  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.88)",zIndex:1000,display:"flex",alignItems:"center",justifyContent:"center",padding:"16px"}}
      onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{background:"#0a0f18",border:"1px solid #1e2d3e",borderRadius:"8px",
        width:"100%",maxWidth:"700px",maxHeight:"92vh",overflowY:"auto",
        boxShadow:"0 30px 100px rgba(0,0,0,0.9)"}}>

        {/* Modal header */}
        <div style={{
          padding:"16px 20px 12px",borderBottom:"1px solid #131e2b",
          display:"flex",alignItems:"center",justifyContent:"space-between",
          position:"sticky",top:0,background:"#0a0f18",zIndex:2,
        }}>
          <span style={{fontFamily:"'Playfair Display',serif",fontSize:"17px",color:"#ddd0b0"}}>
            {isNew ? "New Character" : f.name || "Edit Character"}
          </span>
          <div style={{display:"flex",gap:"8px",alignItems:"center"}}>
            {!isNew && (
              confirmDel ? (
                <>
                  <button onClick={()=>onDelete(f.id)} style={{background:"#2a0e0e",border:"1px solid #6a2020",color:"#e08080",borderRadius:"4px",padding:"4px 10px",cursor:"pointer",fontSize:"11px",fontFamily:"'Courier Prime',monospace"}}>
                    Confirm Delete
                  </button>
                  <button onClick={()=>setConfirmDel(false)} style={{background:"none",border:"1px solid #1a2535",color:"#506070",borderRadius:"4px",padding:"4px 10px",cursor:"pointer",fontSize:"11px",fontFamily:"'Courier Prime',monospace"}}>
                    Cancel
                  </button>
                </>
              ) : (
                <button onClick={()=>setConfirmDel(true)} style={{background:"none",border:"1px solid #3a1515",color:"#8a4040",borderRadius:"4px",padding:"4px 10px",cursor:"pointer",fontSize:"11px",fontFamily:"'Courier Prime',monospace"}}>
                  Delete
                </button>
              )
            )}
            <button onClick={onClose} style={{background:"none",border:"none",color:"#405060",cursor:"pointer",fontSize:"18px"}}>✕</button>
          </div>
        </div>

        {/* Tabs */}
        <div style={{display:"flex",borderBottom:"1px solid #131e2b",padding:"0 20px"}}>
          {[["identity","Identity"],["positions","Positions"+(f.positions?.length?` (${f.positions.length})`:"")]].map(([id,label])=>(
            <button key={id} onClick={()=>setActiveTab(id)} style={{
              background:"none",border:"none",borderBottom:`2px solid ${activeTab===id?"#c9a84c":"transparent"}`,
              color:activeTab===id?"#c9a84c":"#4a6070",padding:"10px 16px",cursor:"pointer",
              fontSize:"12px",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.05em",
              marginBottom:"-1px",
            }}>{label}</button>
          ))}
        </div>

        <div style={{padding:"18px 20px"}}>

          {/* Identity tab */}
          {activeTab==="identity" && (
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"12px"}}>
              <div style={{gridColumn:"1/-1"}}>
                <Inp label="Full Name">
                  <input value={f.name} onChange={e=>set("name",e.target.value)}
                    placeholder="Character name…"
                    style={{...inputStyle,fontSize:"15px",fontFamily:"'Playfair Display',serif",color:"#ddd0b8"}}/>
                </Inp>
              </div>
              <Inp label="Sex">
                <select value={f.sex} onChange={e=>set("sex",e.target.value)}
                  style={{...inputStyle,color:f.sex?sexColorFor(f.sex,settings.sexColorScheme):inputStyle.color,fontWeight:f.sex?700:400}}>
                  <option value="">— select —</option>
                  <option value="Male">{sexDisplayFor("Male",settings)}</option><option value="Female">{sexDisplayFor("Female",settings)}</option>                </select>
              </Inp>
              <Inp label="Realm (Default Primary Jurisdiction)">
                <select value={f.realm||""} onChange={e=>set("realm",e.target.value)} style={inputStyle}>
                  <option value="">— none —</option>
                  <optgroup label="US States">
                    {JURISDICTIONS_US.map(j=><option key={j}>{j}</option>)}
                  </optgroup>
                  <optgroup label="Canadian Provinces">
                    {JURISDICTIONS_CA.map(j=><option key={j}>{j}</option>)}
                  </optgroup>
                </select>
              </Inp>
              <Inp label="Source">
                <input value={f.source} onChange={e=>set("source",e.target.value)}
                  placeholder="e.g. Original, Adapted…" style={inputStyle}/>
              </Inp>
              <Inp label="Type Affiliation 1">
                <select value={f.type1||""} onChange={e=>set("type1",e.target.value)} style={{...inputStyle,color:f.type1?TYPE_COLOR[f.type1]:inputStyle.color,fontWeight:f.type1?700:400}}>
                  <option value="">— none —</option>
                  {ALL_TYPES.map(t=><option key={t} value={t}>{typeLabel(t)}</option>)}
                </select>
              </Inp>
              <Inp label="Type Affiliation 2 (optional)">
                <select value={f.type2||""} onChange={e=>set("type2",e.target.value)} style={{...inputStyle,color:f.type2?TYPE_COLOR[f.type2]:inputStyle.color,fontWeight:f.type2?700:400}}>
                  <option value="">— none —</option>
                  {ALL_TYPES.filter(t=>t!==f.type1).map(t=><option key={t} value={t}>{typeLabel(t)}</option>)}
                </select>
              </Inp>
              {(f.type1||f.type2) && (
                <div style={{gridColumn:"1/-1",display:"flex",gap:"6px"}}>
                  {f.type1 && <Badge label={typeLabel(f.type1)} color={TYPE_COLOR[f.type1]} glow={typeGlow(f.type1)}/>}
                  {f.type2 && <Badge label={typeLabel(f.type2)} color={TYPE_COLOR[f.type2]} glow={typeGlow(f.type2)}/>}
                </div>
              )}
              <div style={{gridColumn:"1/-1",borderTop:"1px solid #131e2b",paddingTop:"12px",marginTop:"2px"}}>
                <div style={{fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:"10px"}}>
                  Additional Jurisdictions
                </div>
                <div style={{display:"flex",flexDirection:"column",gap:"12px"}}>
                  <JurisdictionTagList
                    label="Additional Primary Jurisdictions"
                    values={f.additionalPrimary||[]}
                    onChange={v=>set("additionalPrimary",v)}
                    usedElsewhere={[f.realm,...(f.secondary||[]),...(f.tertiary||[]),...(f.additionalPrimary||[])].filter(Boolean)}
                    accentColor="#c9a84c"
                  />
                  <JurisdictionTagList
                    label="Secondary Jurisdictions"
                    values={f.secondary||[]}
                    onChange={v=>set("secondary",v)}
                    usedElsewhere={[f.realm,...(f.additionalPrimary||[]),...(f.tertiary||[]),...(f.secondary||[])].filter(Boolean)}
                    accentColor="#5aa4d0"
                  />
                  <JurisdictionTagList
                    label="Tertiary Jurisdictions"
                    values={f.tertiary||[]}
                    onChange={v=>set("tertiary",v)}
                    usedElsewhere={[f.realm,...(f.additionalPrimary||[]),...(f.secondary||[]),...(f.tertiary||[])].filter(Boolean)}
                    accentColor="#6a7a8a"
                  />
                </div>
              </div>
              <div style={{gridColumn:"1/-1"}}>
                <Inp label="Designations">
                  <textarea value={f.designations} onChange={e=>set("designations",e.target.value)}
                    placeholder="Titles, honors, distinctions…" rows={3}
                    style={{...inputStyle,resize:"vertical",lineHeight:1.6}}/>
                </Inp>
              </div>
              <div style={{gridColumn:"1/-1"}}>
                <Inp label="Description">
                  <textarea value={f.description} onChange={e=>set("description",e.target.value)}
                    placeholder="Description…" rows={3}
                    style={{...inputStyle,resize:"vertical",lineHeight:1.6}}/>
                </Inp>
              </div>
              <div style={{gridColumn:"1/-1"}}>
                <PairingSection
                  thisChar={char}
                  isNew={isNew}
                  allChars={allChars}
                  pairings={pairings}
                  onAddPairing={onAddPairing}
                  onRemovePairing={onRemovePairing}
                  formRule={!!f.utahLabradorRule}
                  onFormRuleChange={v=>set("utahLabradorRule",v)}
                />
              </div>
              <div style={{gridColumn:"1/-1"}}>
                <RelationsSection
                  thisChar={char}
                  isNew={isNew}
                  allChars={allChars}
                  relationships={relationships}
                  onAddRelation={onAddRelation}
                  onRemoveRelation={onRemoveRelation}
                />
              </div>
            </div>
          )}

          {/* Positions tab */}
          {activeTab==="positions" && (
            <div>
              {curPositions.length > 0 && (
                <div style={{marginBottom:"14px"}}>
                  <div style={{fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:"8px"}}>Current Positions</div>
                  <div style={{display:"flex",flexDirection:"column",gap:"6px"}}>
                    {curPositions.map((p,i)=>(
                      <div key={p.id} style={{position:"relative"}}>
                        <PositionPill pos={p}/>
                        <button onClick={()=>set("positions",f.positions.filter(x=>x.id!==p.id))}
                          style={{position:"absolute",top:"6px",right:"8px",background:"none",border:"none",color:"#3a2020",cursor:"pointer",fontSize:"13px",lineHeight:1}}>✕</button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {pastPositions.length > 0 && (
                <div style={{marginBottom:"14px"}}>
                  <div style={{fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:"8px"}}>Former Positions</div>
                  <div style={{display:"flex",flexDirection:"column",gap:"6px"}}>
                    {pastPositions.map((p,i)=>(
                      <div key={p.id} style={{position:"relative"}}>
                        <PositionPill pos={p}/>
                        <button onClick={()=>set("positions",f.positions.filter(x=>x.id!==p.id))}
                          style={{position:"absolute",top:"6px",right:"8px",background:"none",border:"none",color:"#3a2020",cursor:"pointer",fontSize:"13px",lineHeight:1}}>✕</button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {!addPos && (
                <button onClick={()=>setAddPos(true)} style={{
                  background:"#0a180e",border:"1px solid #1a4028",color:"#4caf72",
                  borderRadius:"4px",padding:"7px 14px",cursor:"pointer",
                  fontSize:"12px",fontFamily:"'Courier Prime',monospace",fontWeight:700,
                }}>+ Add Position</button>
              )}
              {addPos && (
                <AddPositionForm
                  onAdd={p=>{set("positions",[...(f.positions||[]),p]);setAddPos(false);}}
                  onCancel={()=>setAddPos(false)}/>
              )}
            </div>
          )}

          {/* Save */}
          <div style={{display:"flex",justifyContent:"flex-end",gap:"8px",marginTop:"18px",paddingTop:"14px",borderTop:"1px solid #131e2b"}}>
            <button onClick={onClose} style={{background:"none",border:"1px solid #1e2d3e",color:"#506070",borderRadius:"4px",padding:"7px 18px",cursor:"pointer",fontSize:"12px",fontFamily:"'Courier Prime',monospace"}}>Cancel</button>
            <button onClick={()=>onSave(f)} style={{background:"#101e30",border:"1px solid #1e4060",color:"#6aaccc",borderRadius:"4px",padding:"7px 18px",cursor:"pointer",fontSize:"12px",fontFamily:"'Courier Prime',monospace",fontWeight:700}}>
              Save Character
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── CharCard ──────────────────────────────────────────────────────────────────

function CharCard({c, showJur=true, onEdit, onDelete}) {
  const { settings } = useSettings();
  const [hovered, setHovered] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const cur = (c.positions||[]).filter(p=>p.isCurrent);
  const top = getTopPosition(c);
  return (
    <div
      style={{
        background:"#080c11", border:`1px solid ${hovered?"#253545":"#131e2b"}`,
        borderRadius:"6px", padding:"13px 15px", position:"relative",
        overflow:"hidden", transition:"border-color 0.12s, transform 0.12s",
        transform: hovered?"translateY(-1px)":"",
      }}
      onMouseEnter={()=>setHovered(true)}
      onMouseLeave={()=>setHovered(false)}
    >
      {top && <div style={{position:"absolute",top:0,left:0,width:"3px",height:"100%",background:col(top.institutionType)}}/>}
      {/* Delete — two-step, no browser dialog (blocked in sandboxed iframes) */}
      {confirmDel ? (
        <div style={{position:"absolute",top:"5px",right:"6px",display:"flex",gap:"4px",zIndex:2}}>
          <button onClick={e=>{e.stopPropagation();onDelete(c.id);}}
            style={{background:"#2a0e0e",border:"1px solid #6a2020",color:"#e08080",borderRadius:"3px",
              padding:"2px 7px",cursor:"pointer",fontSize:"10px",fontFamily:"'Courier Prime',monospace"}}>
            Delete
          </button>
          <button onClick={e=>{e.stopPropagation();setConfirmDel(false);}}
            style={{background:"none",border:"1px solid #1a2535",color:"#506070",borderRadius:"3px",
              padding:"2px 7px",cursor:"pointer",fontSize:"10px",fontFamily:"'Courier Prime',monospace"}}>
            Cancel
          </button>
        </div>
      ) : (
        <button
          onClick={e=>{e.stopPropagation();setConfirmDel(true);}}
          style={{
            position:"absolute",top:"7px",right:"8px",
            background:"none",border:"none",
            color:hovered?"#8a3535":"transparent",
            cursor:"pointer",fontSize:"13px",lineHeight:1,
            transition:"color 0.12s",padding:"2px 4px",zIndex:2,
          }}
          title="Delete character"
        >✕</button>
      )}
      {/* Body — click to edit */}
      <div onClick={()=>onEdit(c)} style={{cursor:"pointer",paddingRight:"18px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:"6px",marginBottom:"3px"}}>
          <div style={{fontFamily:"'Playfair Display',serif",fontSize:"15px",color:"#cdc0a8"}}>
            {c.name||<span style={{color:"#2a3a4a"}}>Unnamed</span>}
          </div>
          {c.sex && <Badge label={sexDisplayFor(c.sex,settings)} color={sexColorFor(c.sex,settings.sexColorScheme)||"#607080"} glow={sexGlowFor(c.sex,settings.sexColorScheme)}/>}
        </div>
        {showJur && c.realm && (
          <div style={{fontSize:"11px",color:"#3a5060",marginBottom:"5px",display:"flex",alignItems:"center",gap:"5px",flexWrap:"wrap"}}>
            <span>{c.realm} · {isProvince(c.realm)?"Province":"State"}</span>
            {(c.additionalPrimary?.length||c.secondary?.length||c.tertiary?.length) ? (
              <span style={{fontSize:"9px",color:"#2a3a4a",fontFamily:"'Courier Prime',monospace"}}>
                {c.additionalPrimary?.length ? `+${c.additionalPrimary.length}AP ` : ""}
                {c.secondary?.length ? `+${c.secondary.length}S ` : ""}
                {c.tertiary?.length ? `+${c.tertiary.length}T` : ""}
              </span>
            ) : null}
          </div>
        )}
        {(c.type1||c.type2) && (
          <div style={{display:"flex",gap:"4px",flexWrap:"wrap",marginBottom:"5px"}}>
            {c.type1 && <Badge label={typeLabel(c.type1)} color={TYPE_COLOR[c.type1]} glow={typeGlow(c.type1)}/>}
            {c.type2 && <Badge label={typeLabel(c.type2)} color={TYPE_COLOR[c.type2]} glow={typeGlow(c.type2)}/>}
          </div>
        )}
        {cur.length>0 && (
          <div style={{display:"flex",gap:"4px",flexWrap:"wrap",marginBottom:"3px"}}>
            {cur.slice(0,2).map(p=><Badge key={p.id} label={p.title} color={col(p.institutionType)}/>)}
            {cur.length>2 && <span style={{fontSize:"10px",color:"#3a4a5a",alignSelf:"center"}}>+{cur.length-2}</span>}
          </div>
        )}
        {c.designations && (
          <div style={{fontSize:"10px",color:"#4a5a6a",marginTop:"4px",fontStyle:"italic",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
            {c.designations}
          </div>
        )}
      </div>
    </div>
  );
}

// ── GroupedView ───────────────────────────────────────────────────────────────

function GroupedView({chars, onEdit, onDelete}) {
  const [open, setOpen] = useState({});
  const toggle = (key) => setOpen(o=>({...o,[key]:!o[key]}));

  // Build groups
  const groupMap = {};
  chars.forEach(c=>{
    const key = c.realm||"__none__";
    if (!groupMap[key]) groupMap[key]=[];
    groupMap[key].push(c);
  });
  // Sort chars within each group by position priority
  Object.values(groupMap).forEach(arr=>arr.sort((a,b)=>getTopScore(a)-getTopScore(b)));
  // Sort group keys in canonical jurisdiction order
  const jurOrder = [...JURISDICTIONS_US,...JURISDICTIONS_CA];
  const groupKeys = Object.keys(groupMap).sort((a,b)=>{
    if (a==="__none__") return 1; if (b==="__none__") return -1;
    return jurOrder.indexOf(a)-jurOrder.indexOf(b);
  });

  return (
    <div style={{display:"flex",flexDirection:"column",gap:"4px"}}>
      {groupKeys.map(key=>{
        const isNone = key==="__none__";
        const isOpen = !!open[key];
        const chars  = groupMap[key];
        const sov    = !isNone ? SOVEREIGNTY_MAP[key] : null;
        const jurType= !isNone ? (isProvince(key)?"Province":"State") : null;

        return (
          <div key={key} style={{border:"1px solid #131e2b",borderRadius:"6px",overflow:"hidden"}}>
            {/* Folder header */}
            <div
              onClick={()=>toggle(key)}
              style={{
                display:"flex",alignItems:"center",gap:"10px",
                padding:"10px 14px",cursor:"pointer",
                background: isOpen?"#0c1520":"#080c11",
                borderBottom: isOpen?"1px solid #131e2b":"none",
                transition:"background 0.12s",
                userSelect:"none",
              }}
              onMouseEnter={e=>e.currentTarget.style.background="#0e1a28"}
              onMouseLeave={e=>e.currentTarget.style.background=isOpen?"#0c1520":"#080c11"}
            >
              {/* Chevron */}
              <span style={{
                fontSize:"10px",color:"#3a5060",
                transform:isOpen?"rotate(90deg)":"rotate(0deg)",
                transition:"transform 0.15s",display:"inline-block",
                flexShrink:0,
              }}>▶</span>
              {/* Name */}
              <span style={{
                fontFamily:"'Playfair Display',serif",
                fontSize:"15px",
                color: isNone?"#3a4a5a":"#c8b888",
                flex:1,
              }}>
                {isNone?"Unassigned":key}
              </span>
              {/* Badges */}
              {sov && <Badge label={sov} color="#c9a84c"/>}
              {jurType && <Badge label={jurType} color={isProvince(key)?"#6aaec8":"#5aa4d0"}/>}
              {/* Count */}
              <span style={{fontSize:"10px",color:"#2a3a4a",fontFamily:"'Courier Prime',monospace",flexShrink:0}}>
                {chars.length} {chars.length===1?"character":"characters"}
              </span>
            </div>

            {/* Folder contents */}
            {isOpen && (
              <div style={{padding:"12px",background:"#060a0f"}}>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:"8px"}}>
                  {chars.map(c=>(
                    <CharCard key={c.id} c={c} showJur={false} onEdit={onEdit} onDelete={onDelete}/>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── SourceGroupedGrid ─────────────────────────────────────────────────────────

function SourceGroupedGrid({chars, onEdit, onDelete}) {
  const [open, setOpen] = useState({});
  const toggle = (key) => setOpen(o=>({...o,[key]:!o[key]}));

  const groupMap = {};
  chars.forEach(c=>{
    const key = c.source?.trim() || "__none__";
    if (!groupMap[key]) groupMap[key]=[];
    groupMap[key].push(c);
  });
  Object.values(groupMap).forEach(arr=>arr.sort((a,b)=>getTopScore(a)-getTopScore(b)));
  const groupKeys = Object.keys(groupMap).sort((a,b)=>{
    if (a==="__none__") return 1; if (b==="__none__") return -1;
    return a.localeCompare(b);
  });

  return (
    <div style={{display:"flex",flexDirection:"column",gap:"4px"}}>
      {groupKeys.map(key=>{
        const isNone = key==="__none__";
        const isOpen = !!open[key];
        const group  = groupMap[key];
        return (
          <div key={key} style={{border:"1px solid #131e2b",borderRadius:"6px",overflow:"hidden"}}>
            <div
              onClick={()=>toggle(key)}
              style={{
                display:"flex",alignItems:"center",gap:"10px",padding:"10px 14px",
                cursor:"pointer",background:isOpen?"#0c1520":"#080c11",
                borderBottom:isOpen?"1px solid #131e2b":"none",
                transition:"background 0.12s",userSelect:"none",
              }}
              onMouseEnter={e=>e.currentTarget.style.background="#0e1a28"}
              onMouseLeave={e=>e.currentTarget.style.background=isOpen?"#0c1520":"#080c11"}
            >
              <span style={{fontSize:"10px",color:"#3a5060",
                transform:isOpen?"rotate(90deg)":"rotate(0deg)",
                transition:"transform 0.15s",display:"inline-block",flexShrink:0}}>▶</span>
              <span style={{
                fontFamily:"'Playfair Display',serif",fontSize:"15px",flex:1,
                color:isNone?"#3a4a5a":"#c8d8e8",fontStyle:isNone?"italic":"normal",
              }}>
                {isNone?"No Source":key}
              </span>
              <span style={{fontSize:"10px",color:"#2a3a4a",fontFamily:"'Courier Prime',monospace",flexShrink:0}}>
                {group.length} {group.length===1?"character":"characters"}
              </span>
            </div>
            {isOpen && (
              <div style={{padding:"12px",background:"#060a0f"}}>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:"8px"}}>
                  {group.map(c=>(
                    <CharCard key={c.id} c={c} showJur={true} onEdit={onEdit} onDelete={onDelete}/>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── SourceGroupedTable ────────────────────────────────────────────────────────

function SourceGroupedTable({chars, onEdit, onDelete}) {
  const { settings } = useSettings();
  const [pendingDelete, setPendingDelete] = useState(null);
  const [open, setOpen] = useState({});
  const toggle = (key) => setOpen(o=>({...o,[key]:!o[key]}));

  // Group by source
  const groupMap = {};
  chars.forEach(c=>{
    const key = c.source?.trim() || "__none__";
    if (!groupMap[key]) groupMap[key]=[];
    groupMap[key].push(c);
  });
  // Sort within each group by position priority
  Object.values(groupMap).forEach(arr=>arr.sort((a,b)=>getTopScore(a)-getTopScore(b)));
  // Source groups sorted alphabetically, no-source last
  const groupKeys = Object.keys(groupMap).sort((a,b)=>{
    if (a==="__none__") return 1; if (b==="__none__") return -1;
    return a.localeCompare(b);
  });

  const TH = {padding:"7px 12px",textAlign:"left",color:"#3a5060",fontSize:"10px",
    letterSpacing:"0.1em",textTransform:"uppercase",fontWeight:700,
    fontFamily:"'Courier Prime',monospace"};

  return (
    <div style={{display:"flex",flexDirection:"column",gap:"4px"}}>
      {groupKeys.map(key=>{
        const isNone = key==="__none__";
        const isOpen = !!open[key];
        const group  = groupMap[key];
        return (
          <div key={key} style={{border:"1px solid #131e2b",borderRadius:"6px",overflow:"hidden"}}>
            {/* Folder header */}
            <div
              onClick={()=>toggle(key)}
              style={{
                display:"flex",alignItems:"center",gap:"10px",padding:"10px 14px",
                cursor:"pointer",background:isOpen?"#0c1520":"#080c11",
                borderBottom:isOpen?"1px solid #131e2b":"none",
                transition:"background 0.12s",userSelect:"none",
              }}
              onMouseEnter={e=>e.currentTarget.style.background="#0e1a28"}
              onMouseLeave={e=>e.currentTarget.style.background=isOpen?"#0c1520":"#080c11"}
            >
              <span style={{fontSize:"10px",color:"#3a5060",
                transform:isOpen?"rotate(90deg)":"rotate(0deg)",
                transition:"transform 0.15s",display:"inline-block",flexShrink:0}}>▶</span>
              <span style={{
                fontFamily:"'Playfair Display',serif",fontSize:"15px",flex:1,
                color:isNone?"#3a4a5a":"#c8d8e8",fontStyle:isNone?"italic":"normal",
              }}>
                {isNone?"No Source":key}
              </span>
              <span style={{fontSize:"10px",color:"#2a3a4a",fontFamily:"'Courier Prime',monospace",flexShrink:0}}>
                {group.length} {group.length===1?"character":"characters"}
              </span>
            </div>

            {/* Table */}
            {isOpen && (
              <div style={{background:"#060a0f",overflowX:"auto"}}>
                <table style={{width:"100%",borderCollapse:"collapse",fontSize:"12px",fontFamily:"'Courier Prime',monospace"}}>
                  <thead>
                    <tr style={{borderBottom:"1px solid #131e2b",background:"#080c11"}}>
                      {["Name","Sex","Affiliation","Jurisdiction","Current Positions","Designations",""].map(h=>(
                        <th key={h} style={TH}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {group.map((c,i)=>{
                      const cur=(c.positions||[]).filter(p=>p.isCurrent);
                      return (
                        <tr key={c.id}
                          style={{borderBottom:"1px solid #0c1520",background:i%2?"#080c11":"transparent"}}
                          onMouseEnter={e=>e.currentTarget.style.background="#0c1825"}
                          onMouseLeave={e=>e.currentTarget.style.background=i%2?"#080c11":"transparent"}
                        >
                          <td style={{padding:"9px 12px",color:"#cdc0a8",fontFamily:"'Playfair Display',serif",fontSize:"13px",cursor:"pointer",whiteSpace:"nowrap"}}
                            onClick={()=>onEdit(c)}>{c.name}</td>
                          <td style={{padding:"9px 12px",whiteSpace:"nowrap"}}>
                            {c.sex && (
                              <span style={{fontSize:"11px",fontWeight:700,
                                color:sexColorFor(c.sex,settings.sexColorScheme)||"#607080",
                                textShadow:sexGlowFor(c.sex,settings.sexColorScheme),
                                fontFamily:"'Courier Prime',monospace",
                              }}>{sexDisplayFor(c.sex,settings)}</span>
                            )}
                          </td>
                          <td style={{padding:"9px 12px",whiteSpace:"nowrap"}}>
                            <div style={{display:"flex",gap:"4px"}}>
                              {c.type1 && <Badge label={typeLabel(c.type1)} color={TYPE_COLOR[c.type1]} glow={typeGlow(c.type1)}/>}
                              {c.type2 && <Badge label={typeLabel(c.type2)} color={TYPE_COLOR[c.type2]} glow={typeGlow(c.type2)}/>}
                            </div>
                          </td>
                          <td style={{padding:"9px 12px",color:"#506070",whiteSpace:"nowrap"}}>{c.realm}</td>
                          <td style={{padding:"9px 12px"}}>
                            <div style={{display:"flex",gap:"4px",flexWrap:"wrap"}}>
                              {cur.slice(0,2).map(p=><Badge key={p.id} label={p.title} color={col(p.institutionType)}/>)}
                              {cur.length>2&&<span style={{color:"#3a4a5a",fontSize:"10px"}}>+{cur.length-2}</span>}
                            </div>
                          </td>
                          <td style={{padding:"9px 12px",color:"#405060",maxWidth:"180px",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{c.designations}</td>
                          <td style={{padding:"9px 12px",textAlign:"center",whiteSpace:"nowrap"}}>
                            <div style={{display:"flex",gap:"6px",justifyContent:"center"}}>
                              {pendingDelete === c.id ? (
                                <>
                                  <button onClick={()=>{onDelete(c.id);setPendingDelete(null);}}
                                    style={{background:"#2a0e0e",border:"1px solid #6a2020",color:"#e08080",borderRadius:"3px",padding:"3px 8px",cursor:"pointer",fontSize:"10px",fontFamily:"'Courier Prime',monospace"}}>
                                    Delete
                                  </button>
                                  <button onClick={()=>setPendingDelete(null)}
                                    style={{background:"none",border:"1px solid #1a2535",color:"#506070",borderRadius:"3px",padding:"3px 8px",cursor:"pointer",fontSize:"10px",fontFamily:"'Courier Prime',monospace"}}>
                                    Cancel
                                  </button>
                                </>
                              ) : (
                                <>
                                  <button onClick={()=>onEdit(c)}
                                    style={{background:"none",border:"1px solid #1a2535",color:"#4a6a8a",borderRadius:"3px",padding:"3px 8px",cursor:"pointer",fontSize:"10px",fontFamily:"'Courier Prime',monospace"}}>
                                    Edit
                                  </button>
                                  <button onClick={()=>setPendingDelete(c.id)}
                                    style={{background:"none",border:"1px solid #2a1515",color:"#6a3030",borderRadius:"3px",padding:"3px 8px",cursor:"pointer",fontSize:"10px",fontFamily:"'Courier Prime',monospace"}}>
                                    ✕
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────

function AppInner() {
  const { settings, setSettings } = useSettings();
  const [db, setDb]               = useState({ chars:[], nextId:1 });
  const [dbLoaded, setDbLoaded]   = useState(false);
  const [search, setSearch]       = useState("");
  const [fSex, setFSex]           = useState("");
  const [fType, setFType]         = useState("");
  const [fJur, setFJur]           = useState("");
  const [fInst, setFInst]         = useState("");
  const [fStatus, setFStatus]     = useState("");
  const [sortBy, setSortBy]       = useState("name");
  const [viewMode, setViewMode]   = useState("grouped");
  const [modal, setModal]         = useState(null);
  const [settingsOpen, setSettingsOpen] = useState(false);

  // Load character data on mount
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const d = await loadChars();
      if (!cancelled) { setDb(d); setDbLoaded(true); }
    })();
    return () => { cancelled = true; };
  }, []);

  // Persist character data on every change (after initial load)
  useEffect(() => {
    if (!dbLoaded) return;
    saveChars(db);
  }, [db, dbLoaded]);

  const saveChar = (form) => {
    if (!form.name.trim()) return;
    setDb(d => {
      if (modal.isNew) return {chars:[...d.chars,{...form,id:d.nextId}],nextId:d.nextId+1};
      return {...d, chars:d.chars.map(c=>c.id===form.id?form:c)};
    });
    setModal(null);
  };

  const deleteChar = (id) => {
    setDb(d=>({...d,chars:d.chars.filter(c=>c.id!==id)}));
    setModal(null);
  };

  // Replaces the entire database with an imported one (from Settings → Data Management).
  // Routes through migrateDatabase so any schema version — old or new — normalizes cleanly.
  const importDb = (imported) => {
    setDb(migrateDatabase(imported));
  };

  // ── Relations ──────────────────────────────────────────────────────────────
  // Relations are always binary and stored once, at the top level (db.relationships),
  // regardless of which character's modal was open when they were created. A single
  // relation record captures all three factors: the nature of the relationship, and
  // each side's specific role within it. charB is null when the typed partner name
  // doesn't match an existing character — otherName is kept either way as the raw
  // typed reference, so the relation still displays correctly.
  const addRelation = (charAId, charBId, otherName, nature, roleA, roleB) => {
    setDb(d => ({
      ...d,
      relationships: [...(d.relationships||[]), {
        id: uid(), charA: charAId, charB: charBId, otherName, nature, roleA, roleB,
      }],
    }));
  };
  const removeRelation = (relationId) => {
    setDb(d => ({ ...d, relationships: (d.relationships||[]).filter(r=>r.id!==relationId) }));
  };

  // ── Romantic pairings ──────────────────────────────────────────────────────
  // Unordered binary links between one male and one female character, with no
  // rank or precedence field: partners stand at equal parity by design.
  // The Utah-Labrador rule is a *permission* flag, not a status — a character
  // must have it enabled before they can hold more than one pairing, and before
  // they can be paired to someone who already holds one.
  const addPairing = (charAId, charBId) => {
    setDb(d => {
      const existing = d.pairings || [];
      // Never duplicate a pairing regardless of which side it was created from
      const already = existing.some(p =>
        (p.a===charAId && p.b===charBId) || (p.a===charBId && p.b===charAId));
      if (already) return d;
      return { ...d, pairings: [...existing, { id: uid(), a: charAId, b: charBId }] };
    });
  };
  const removePairing = (pairingId) => {
    setDb(d => ({ ...d, pairings: (d.pairings||[]).filter(p=>p.id!==pairingId) }));
  };

  const filtered = useMemo(()=>{
    let list = db.chars;
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(c=>
        c.name?.toLowerCase().includes(q) ||
        c.source?.toLowerCase().includes(q) ||
        c.designations?.toLowerCase().includes(q) ||
        (c.positions||[]).some(p=>p.title?.toLowerCase().includes(q)||p.jurisdiction?.toLowerCase().includes(q)||p.house?.toLowerCase().includes(q)||p.estateName?.toLowerCase().includes(q))
      );
    }
    if (fSex) list = list.filter(c=>c.sex===fSex);
    if (fType) list = list.filter(c=>c.type1===fType||c.type2===fType);
    if (fJur) list = list.filter(c=>allJurisdictionsOf(c).includes(fJur));
    if (fInst) list = list.filter(c=>(c.positions||[]).some(p=>p.institutionType===fInst));
    if (fStatus==="current") list = list.filter(c=>(c.positions||[]).some(p=>p.isCurrent));
    if (fStatus==="none") list = list.filter(c=>!(c.positions||[]).length);
    list = [...list].sort((a,b)=>{
      if (sortBy==="name") return (a.name||"").localeCompare(b.name||"");
      if (sortBy==="jur")  return (a.realm||"").localeCompare(b.realm||"");
      if (sortBy==="new")  return b.id-a.id;
      return 0;
    });
    return list;
  },[db.chars,search,fSex,fType,fJur,fInst,fStatus,sortBy]);

  const stats = useMemo(()=>({
    total: db.chars.length,
    active: db.chars.filter(c=>(c.positions||[]).some(p=>p.isCurrent)).length,
    jurs: new Set(db.chars.flatMap(c=>allJurisdictionsOf(c))).size,
  }),[db.chars]);

  const sel = {
    background:"#080c11",border:"1px solid #1a2535",color:"#8aaabb",
    borderRadius:"4px",padding:"6px 10px",fontSize:"12px",
    fontFamily:"'Courier Prime',monospace",
  };

  return (
    <div style={{minHeight:"100vh",background:"#060a0f",color:"#b8c8d8",fontFamily:"'Crimson Pro',serif",overflowX:"auto"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Courier+Prime:wght@400;700&family=Crimson+Pro:wght@300;400;600&display=swap');
        *{box-sizing:border-box;}
        html,body{overflow-x:auto;background:#060a0f;margin:0;padding:0;}
        ::selection{background:#c9a84c33;}
        ::-webkit-scrollbar{height:6px;width:5px;background:#080c11;}
        ::-webkit-scrollbar-thumb{background:#1a2535;border-radius:3px;}
        select option{background:#0a0f18;}
        input::placeholder,textarea::placeholder{color:#2a3a4a;}
      `}</style>

      {/* ── Top bar ── */}
      <header style={{background:"#080c11",borderBottom:"1px solid #131e2b",padding:"0 24px",position:"sticky",top:0,zIndex:100}}>
        <div style={{maxWidth:"1440px",margin:"0 auto",display:"flex",alignItems:"center",justifyContent:"space-between",height:"52px"}}>
          <div style={{display:"flex",alignItems:"baseline",gap:"12px"}}>
            <span style={{fontFamily:"'Playfair Display',serif",fontSize:"19px",color:"#c9a84c",letterSpacing:"0.03em"}}>REGISTRY</span>
            <span style={{fontSize:"10px",color:"#2a3a4a",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.12em"}}>CHARACTER DATABASE</span>
          </div>
          <div style={{display:"flex",gap:"18px",alignItems:"center"}}>
            <div style={{display:"flex",gap:"14px",fontSize:"11px",fontFamily:"'Courier Prime',monospace"}}>
              <span style={{color:"#3a4a5a"}}><span style={{color:"#7a9aaa"}}>{stats.total}</span> entries</span>
              <span style={{color:"#3a4a5a"}}><span style={{color:"#5caf78"}}>{stats.active}</span> assigned</span>
              <span style={{color:"#3a4a5a"}}><span style={{color:"#c9a84c"}}>{stats.jurs}</span> jurisdictions</span>
            </div>
            <button onClick={()=>setSettingsOpen(true)} title="Settings" style={{
              background:"none",border:"1px solid #1a2535",color:"#4a6070",
              borderRadius:"4px",padding:"6px 10px",cursor:"pointer",fontSize:"13px",
            }}>⚙</button>
            <button onClick={()=>setModal({char:null,isNew:true})} style={{
              background:"#0a180e",border:"1px solid #1e4a2e",color:"#5caf78",
              borderRadius:"4px",padding:"6px 16px",cursor:"pointer",
              fontSize:"12px",fontFamily:"'Courier Prime',monospace",fontWeight:700,
              letterSpacing:"0.06em",
            }}>+ NEW CHARACTER</button>
          </div>
        </div>
      </header>

      <div style={{maxWidth:"1440px",margin:"0 auto",padding:"18px 24px"}}>

        {/* ── Filter bar ── */}
        <div style={{background:"#080c11",border:"1px solid #131e2b",borderRadius:"6px",padding:"12px 14px",marginBottom:"16px",display:"flex",gap:"8px",flexWrap:"wrap",alignItems:"center"}}>
          <input value={search} onChange={e=>setSearch(e.target.value)}
            placeholder="Search names, positions, sources, jurisdictions…"
            style={{...sel,flex:"1 1 200px",padding:"7px 12px",fontSize:"12px",color:"#c0d0e0"}}/>
          <select value={fSex} onChange={e=>setFSex(e.target.value)}
            style={{...sel,color:fSex?sexColorFor(fSex,settings.sexColorScheme):sel.color,fontWeight:fSex?700:400}}>
            <option value="">All sexes</option>
            <option value="Male">{sexDisplayFor("Male",settings)}</option><option value="Female">{sexDisplayFor("Female",settings)}</option>
          </select>
          <select value={fType} onChange={e=>setFType(e.target.value)} style={{...sel,color:fType?TYPE_COLOR[fType]:sel.color}}>
            <option value="">All affiliations</option>
            {ALL_TYPES.map(t=><option key={t} value={t}>{typeLabel(t)}</option>)}
          </select>
          <select value={fJur} onChange={e=>setFJur(e.target.value)} style={sel}>
            <option value="">All jurisdictions</option>
            <optgroup label="US States">{JURISDICTIONS_US.map(j=><option key={j}>{j}</option>)}</optgroup>
            <optgroup label="Canadian Provinces">{JURISDICTIONS_CA.map(j=><option key={j}>{j}</option>)}</optgroup>
          </select>
          <select value={fInst} onChange={e=>setFInst(e.target.value)} style={sel}>
            <option value="">All institutions</option>
            {INSTITUTION_TYPES.map(t=><option key={t}>{t}</option>)}
          </select>
          <select value={fStatus} onChange={e=>setFStatus(e.target.value)} style={sel}>
            <option value="">All status</option>
            <option value="current">Has current position</option>
            <option value="none">No positions</option>
          </select>
          <select value={sortBy} onChange={e=>setSortBy(e.target.value)} style={sel}>
            <option value="name">Sort: Name</option>
            <option value="jur">Sort: Jurisdiction</option>
            <option value="new">Sort: Recently added</option>
          </select>
          <div style={{display:"flex",gap:"3px",marginLeft:"auto"}}>
            {[["grid","⊞"],["grouped","⊟"],["table","≡"]].map(([v,icon])=>(
              <button key={v} onClick={()=>setViewMode(v)} style={{
                background:viewMode===v?"#101e30":"none",
                border:`1px solid ${viewMode===v?"#1e4060":"#131e2b"}`,
                color:viewMode===v?"#6aaccc":"#304050",
                borderRadius:"4px",padding:"5px 10px",cursor:"pointer",
                fontSize:"13px",
              }}>{icon}</button>
            ))}
          </div>
        </div>

        <div style={{fontSize:"10px",color:"#2a3a4a",fontFamily:"'Courier Prime',monospace",marginBottom:"12px"}}>
          {filtered.length} of {db.chars.length} characters
        </div>

        {/* ── Loading state ── */}
        {!dbLoaded && (
          <div style={{textAlign:"center",padding:"70px 20px",color:"#2a3a4a"}}>
            <div style={{fontSize:"13px",fontFamily:"'Courier Prime',monospace"}}>Loading registry…</div>
          </div>
        )}

        {/* ── Empty state ── */}
        {dbLoaded && filtered.length===0 && (
          <div style={{textAlign:"center",padding:"70px 20px",color:"#1e2e3e"}}>
            <div style={{fontSize:"36px",marginBottom:"14px",opacity:0.5}}>⊘</div>
            <div style={{fontFamily:"'Playfair Display',serif",fontSize:"17px",marginBottom:"6px",color:"#2e3e4e"}}>
              {db.chars.length===0?"No characters yet":"No results"}
            </div>
            <div style={{fontSize:"13px",color:"#1e2e3e"}}>
              {db.chars.length===0?"Click + NEW CHARACTER to begin.":"Try adjusting your filters."}
            </div>
          </div>
        )}

        {/* ── Grid view — grouped by source ── */}
        {dbLoaded && viewMode==="grid" && filtered.length>0 && (
          <SourceGroupedGrid
            chars={filtered}
            onEdit={c=>setModal({char:c,isNew:false})}
            onDelete={deleteChar}/>
        )}

        {/* ── Grouped (folder) view ── */}
        {dbLoaded && viewMode==="grouped" && filtered.length>0 && (
          <GroupedView
            chars={filtered}
            onEdit={c=>setModal({char:c,isNew:false})}
            onDelete={deleteChar}/>
        )}

        {/* ── Table view — grouped by source ── */}
        {dbLoaded && viewMode==="table" && filtered.length>0 && (
          <SourceGroupedTable
            chars={filtered}
            onEdit={c=>setModal({char:c,isNew:false})}
            onDelete={deleteChar}/>
        )}
      </div>

      {/* ── Modal ── */}
      {modal && (
        <CharModal
          char={modal.char}
          isNew={modal.isNew}
          onSave={saveChar}
          onDelete={deleteChar}
          onClose={()=>setModal(null)}
          allChars={db.chars}
          relationships={db.relationships||[]}
          onAddRelation={addRelation}
          pairings={db.pairings||[]}
          onAddPairing={addPairing}
          onRemovePairing={removePairing}
          onRemoveRelation={removeRelation}
        />
      )}

      {/* ── Settings modal ── */}
      {settingsOpen && (
        <SettingsModal
          settings={settings}
          onChange={setSettings}
          onClose={()=>setSettingsOpen(false)}
          db={db}
          onImportDb={importDb}
        />
      )}
    </div>
  );
}

// ── Settings Modal ────────────────────────────────────────────────────────────

function SettingsModal({settings, onChange, onClose, db, onImportDb}) {
  const [statusMsg, setStatusMsg]     = useState("");
  const [statusKind, setStatusKind]   = useState("info"); // "info" | "error" | "success"
  const [pasteText, setPasteText]     = useState("");
  const [pendingLoad, setPendingLoad] = useState(null); // staged import awaiting in-app confirmation
  const [dragOver, setDragOver]       = useState(false);
  const [showFileOptions, setShowFileOptions] = useState(false);
  const exportTextareaRef = React.useRef(null);
  const fileInputRef      = React.useRef(null);
  const backupInputRef    = React.useRef(null);

  // File System Access API — lets Save overwrite the SAME on-disk file every time,
  // instead of producing a new download each time. Only available in Chromium
  // browsers, and only from a top-level page (it throws inside cross-origin
  // iframes, which is how this app runs when embedded as a Claude.ai artifact).
  const fsApiExists = typeof window !== "undefined" && "showSaveFilePicker" in window;
  const [mainHandle, setMainHandle]     = useState(null);
  const [backupHandle, setBackupHandle] = useState(null);
  const [fsBlocked, setFsBlocked]       = useState(false);

  useEffect(() => {
    if (!fsApiExists) return;
    (async () => {
      try {
        const m = await idbGet("mainFile");
        if (m) setMainHandle(m);
        const b = await idbGet("backupFile");
        if (b) setBackupHandle(b);
      } catch (e) { /* no stored handle yet */ }
    })();
  }, []);

  const showStatus = (msg, kind="info") => { setStatusMsg(msg); setStatusKind(kind); };

  const buildExportPayload = () => ({
    ...db,
    schemaVersion: SCHEMA_VERSION,
    relationships: db.relationships || [],
    savedAt: new Date().toISOString(),
  });
  const exportText = JSON.stringify(buildExportPayload(), null, 2);

  // ── Copy / Paste — the guaranteed-to-work method ──────────────────────────
  // Doesn't rely on file downloads, file pickers, or any browser permission that
  // a sandboxed embed (like this app running as a Claude.ai artifact) might block.
  // Worst case, the user can always manually select the text and copy it by hand.

  const copyExportToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(exportText);
      showStatus("Copied to clipboard.", "success");
    } catch (e) {
      if (exportTextareaRef.current) {
        exportTextareaRef.current.focus();
        exportTextareaRef.current.select();
      }
      showStatus("Clipboard access is blocked here — the text is now selected, just press Ctrl+C (or Cmd+C) to copy it yourself.", "info");
    }
  };

  const loadFromPastedText = () => {
    if (!pasteText.trim()) { showStatus("Paste your saved JSON into the box first.", "error"); return; }
    try {
      const parsed = JSON.parse(pasteText);
      if (!parsed || !Array.isArray(parsed.chars)) { showStatus("That doesn't look like a valid Registry database.", "error"); return; }
      const migrated = migrateDatabase(parsed);
      setPendingLoad({ data: migrated, label: "pasted text" });
      showStatus("", "info");
    } catch (e) {
      showStatus("Couldn't parse that text — make sure you pasted the whole thing, unedited.", "error");
    }
  };

  // ── File System Access API path (Chromium browsers, top-level page only) ──

  const connectMain = async () => {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: "registry-database.json",
        types: [{ description: "Registry Database", accept: {"application/json": [".json"]} }],
      });
      setMainHandle(handle);
      await idbSet("mainFile", handle);
      showStatus("Main file connected. Use Save Now to write to it.", "success");
    } catch (e) {
      if (e.name !== "AbortError") { setFsBlocked(true); showStatus("Direct file connection isn't available here.", "error"); }
    }
  };

  const connectBackup = async () => {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: "registry-database-backup.json",
        types: [{ description: "Registry Database Backup", accept: {"application/json": [".json"]} }],
      });
      setBackupHandle(handle);
      await idbSet("backupFile", handle);
      showStatus("Backup file connected.", "success");
    } catch (e) {
      if (e.name !== "AbortError") showStatus("Couldn't connect a backup file.", "error");
    }
  };

  const writeToHandle = async (handle, text) => {
    const writable = await handle.createWritable();
    await writable.write(text);
    await writable.close();
  };
  const readFromHandle = async (handle) => (await handle.getFile()).text();

  const saveNow = async () => {
    if (!mainHandle) return;
    try {
      if (backupHandle) {
        try {
          const currentMain = await readFromHandle(mainHandle);
          if (currentMain) await writeToHandle(backupHandle, currentMain);
        } catch (e) { /* main file may be empty/new on first save — fine */ }
      }
      await writeToHandle(mainHandle, exportText);
      showStatus(`Saved ${db.chars.length} character${db.chars.length===1?"":"s"} to the main file.`, "success");
    } catch (e) {
      showStatus("Save failed: " + e.message, "error");
    }
  };

  const loadFromHandle = async (handle, label) => {
    if (!handle) return;
    try {
      const parsed = JSON.parse(await readFromHandle(handle));
      const migrated = migrateDatabase(parsed);
      setPendingLoad({ data: migrated, label });
      showStatus("", "info");
    } catch (e) {
      showStatus(`Couldn't read the ${label}: ` + e.message, "error");
    }
  };

  const disconnectHandle = async (which) => {
    if (which === "main") { setMainHandle(null); await idbDelete("mainFile"); }
    else { setBackupHandle(null); await idbDelete("backupFile"); }
  };

  // ── File download — uses a real <a download> the user clicks directly.
  // A programmatic a.click() is unreliable inside sandboxed iframes, so the
  // anchor is rendered visibly and the browser handles the click natively.

  const downloadHref = useMemo(() => {
    try { return URL.createObjectURL(new Blob([exportText], {type:"application/json"})); }
    catch (e) { return "data:application/json;charset=utf-8," + encodeURIComponent(exportText); }
  }, [exportText]);

  // ── File upload — reads whatever the user selects or drops, then stages it
  // for in-app confirmation (no window.confirm, which sandboxes block).

  const readFileIntoPending = (file, label="file") => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        if (!parsed || !Array.isArray(parsed.chars)) { showStatus("This doesn't look like a valid Registry database file.", "error"); return; }
        setPendingLoad({ data: migrateDatabase(parsed), label: file.name || label });
        showStatus("", "info");
      } catch (err) {
        showStatus("Couldn't read that file — is it the .json this app saved?", "error");
      }
    };
    reader.onerror = () => showStatus("Couldn't read that file.", "error");
    reader.readAsText(file);
  };

  const handleFileSelect = (e, label="file") => {
    readFileIntoPending(e.target.files?.[0], label);
    e.target.value = "";
  };

  const handleDrop = (e) => {
    e.preventDefault(); setDragOver(false);
    readFileIntoPending(e.dataTransfer.files?.[0], "dropped file");
  };

  const confirmPendingLoad = () => {
    if (!pendingLoad) return;
    const n = pendingLoad.data.chars.length;
    onImportDb(pendingLoad.data);
    setPendingLoad(null);
    setPasteText("");
    showStatus(`Loaded ${n} character${n===1?"":"s"} successfully.`, "success");
  };

  const btnStyle = {
    background:"#0e1a28",border:"1px solid #1e3a52",color:"#6aaccc",
    borderRadius:"5px",padding:"9px 14px",cursor:"pointer",
    fontSize:"12px",fontFamily:"'Courier Prime',monospace",fontWeight:700,
    textAlign:"left",width:"100%",
  };
  const btnGold  = {...btnStyle,background:"#1a1608",borderColor:"#3a2e12",color:"#c9a84c"};
  const btnGhost = {...btnStyle,background:"none",borderColor:"#1a2535",color:"#506070",fontWeight:400};

  const textareaStyle = {
    ...inputStyle, fontSize:"10px", lineHeight:1.5, resize:"vertical",
    minHeight:"90px", whiteSpace:"pre", overflowX:"auto",
  };

  const useDirectFileAccess = fsApiExists && !fsBlocked;

  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",zIndex:1200,display:"flex",alignItems:"center",justifyContent:"center",padding:"16px"}}
      onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{background:"#0a0f18",border:"1px solid #1e2d3e",borderRadius:"8px",width:"100%",maxWidth:"480px",maxHeight:"88vh",overflowY:"auto",boxShadow:"0 30px 100px rgba(0,0,0,0.9)"}}>
        <div style={{padding:"16px 20px",borderBottom:"1px solid #131e2b",display:"flex",alignItems:"center",justifyContent:"space-between",position:"sticky",top:0,background:"#0a0f18",zIndex:1}}>
          <span style={{fontFamily:"'Playfair Display',serif",fontSize:"17px",color:"#ddd0b0"}}>Settings</span>
          <button onClick={onClose} style={{background:"none",border:"none",color:"#405060",cursor:"pointer",fontSize:"18px"}}>✕</button>
        </div>
        <div style={{padding:"20px"}}>

          {/* ── Data Management ── */}
          <div style={{fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:"10px"}}>
            Data Management
          </div>
          <div style={{fontSize:"11px",color:"#6a7a8a",marginBottom:"14px",lineHeight:1.5,fontFamily:"'Crimson Pro',serif"}}>
            The database currently holds <strong style={{color:"#c0d8e8"}}>{db.chars.length}</strong> character{db.chars.length===1?"":"s"}
            {db.relationships?.length ? <> and <strong style={{color:"#c0d8e8"}}>{db.relationships.length}</strong> relationship{db.relationships.length===1?"":"s"}</> : null}.
            {" "}Schema v{SCHEMA_VERSION}.
          </div>

          {/* ── Pending load confirmation (replaces window.confirm) ── */}
          {pendingLoad && (
            <div style={{
              background:"#141a08",border:"1px solid #3a4a12",borderRadius:"6px",
              padding:"12px",marginBottom:"14px",
            }}>
              <div style={{fontSize:"12px",color:"#c9d84c",fontFamily:"'Courier Prime',monospace",marginBottom:"4px",fontWeight:700}}>
                Ready to load from {pendingLoad.label}
              </div>
              <div style={{fontSize:"11px",color:"#8a9a6a",marginBottom:"10px",lineHeight:1.5}}>
                Contains <strong>{pendingLoad.data.chars.length}</strong> character{pendingLoad.data.chars.length===1?"":"s"}
                {pendingLoad.data.relationships?.length ? <> and <strong>{pendingLoad.data.relationships.length}</strong> relationship{pendingLoad.data.relationships.length===1?"":"s"}</> : null}.
                {" "}This will replace everything currently loaded.
              </div>
              <div style={{display:"flex",gap:"8px"}}>
                <button onClick={confirmPendingLoad} style={{
                  background:"#1a2a10",border:"1px solid #4a6a20",color:"#a9c95c",borderRadius:"4px",
                  padding:"7px 14px",cursor:"pointer",fontSize:"12px",fontFamily:"'Courier Prime',monospace",fontWeight:700,
                }}>✓ Replace &amp; Load</button>
                <button onClick={()=>setPendingLoad(null)} style={{
                  background:"none",border:"1px solid #1a2535",color:"#506070",borderRadius:"4px",
                  padding:"7px 14px",cursor:"pointer",fontSize:"12px",fontFamily:"'Courier Prime',monospace",
                }}>Cancel</button>
              </div>
            </div>
          )}

          {/* ── Save: a real <a download>, clicked directly by the user ── */}
          <div style={{fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:"7px"}}>
            Save to File
          </div>
          <a href={downloadHref} download="registry-database.json"
            style={{...btnStyle,display:"block",textDecoration:"none",marginBottom:"6px"}}>
            ⬇ Download registry-database.json
          </a>
          <a href={downloadHref} download="registry-database-backup.json"
            style={{...btnGhost,display:"block",textDecoration:"none",marginBottom:"16px"}}>
            ⬇ Download a second copy as backup
          </a>

          {/* ── Load: a real visible file input + drop zone ── */}
          <div style={{fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:"7px"}}>
            Load from File
          </div>
          <div
            onDragOver={e=>{e.preventDefault();setDragOver(true);}}
            onDragLeave={()=>setDragOver(false)}
            onDrop={handleDrop}
            style={{
              border:`1px dashed ${dragOver?"#c9a84c":"#2a3545"}`,
              background: dragOver?"#141a08":"#080c11",
              borderRadius:"6px",padding:"14px",marginBottom:"8px",
              transition:"border-color 0.12s, background 0.12s",
            }}
          >
            <div style={{fontSize:"11px",color:"#6a7a8a",marginBottom:"9px",lineHeight:1.5}}>
              Choose your saved <strong style={{color:"#c0d8e8"}}>.json</strong> file — or drag and drop it here.
            </div>
            <input type="file" accept="application/json,.json"
              onChange={e=>handleFileSelect(e,"file")}
              style={{
                fontSize:"11px",color:"#8a9aaa",fontFamily:"'Courier Prime',monospace",
                width:"100%",cursor:"pointer",
              }}/>
          </div>

          <div style={{fontSize:"10px",color:"#4a5a6a",fontStyle:"italic",marginBottom:"16px",lineHeight:1.5}}>
            To keep this data available to Claude across new conversations, upload the saved file to
            this Project's <strong style={{color:"#6a7a8a"}}>Files</strong> section (not just this chat).
          </div>

          {/* ── Advanced: alternate methods, only needed if the above doesn't work ── */}
          <button onClick={()=>setShowFileOptions(s=>!s)} style={{
            background:"none",border:"none",color:"#4a6070",cursor:"pointer",
            fontSize:"11px",fontFamily:"'Courier Prime',monospace",padding:"0",marginBottom:"10px",
            textDecoration:"underline",textUnderlineOffset:"3px",
          }}>
            {showFileOptions ? "▾" : "▸"} Still not working? Try copy / paste instead
          </button>

          {showFileOptions && (
            <div style={{marginBottom:"10px"}}>
              {useDirectFileAccess && (
                <>
                  <div style={{fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:"7px"}}>
                    Direct File Connection (Chromium browsers)
                  </div>
                  {mainHandle ? (
                    <div style={{display:"flex",flexDirection:"column",gap:"6px",marginBottom:"14px"}}>
                      <div style={{fontSize:"11px",color:"#5caf78",fontFamily:"'Courier Prime',monospace"}}>
                        ✓ Connected: {mainHandle.name}
                      </div>
                      <button onClick={saveNow} style={btnStyle}>💾 Save Now (overwrite this file)</button>
                      <button onClick={()=>loadFromHandle(mainHandle,"main file")} style={btnGold}>⬆ Reload From This File</button>
                      <button onClick={()=>disconnectHandle("main")} style={btnGhost}>Disconnect main file</button>
                    </div>
                  ) : (
                    <button onClick={connectMain} style={{...btnStyle,marginBottom:"14px"}}>
                      🔗 Connect / Create a Live-Sync File…
                    </button>
                  )}
                </>
              )}

              <div style={{fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:"7px"}}>
                Copy / Paste
              </div>
              <textarea ref={exportTextareaRef} readOnly value={exportText}
                onFocus={e=>e.target.select()}
                style={{...textareaStyle,marginBottom:"6px"}}/>
              <button onClick={copyExportToClipboard} style={{...btnStyle,marginBottom:"10px"}}>
                📋 Copy to Clipboard
              </button>
              <textarea value={pasteText} onChange={e=>setPasteText(e.target.value)}
                placeholder="Paste previously-saved database text here…"
                style={{...textareaStyle,marginBottom:"6px"}}/>
              <button onClick={loadFromPastedText} style={btnGold}>
                ⬆ Load From Pasted Text
              </button>
            </div>
          )}

          {statusMsg && (
            <div style={{
              fontSize:"11px",marginTop:"6px",marginBottom:"10px",padding:"8px 10px",borderRadius:"4px",
              fontFamily:"'Courier Prime',monospace",
              color: statusKind==="error"?"#e08080":statusKind==="success"?"#5caf78":"#8a9aaa",
              background: statusKind==="error"?"#1a0a0a":statusKind==="success"?"#0a180e":"#0a0f18",
              border:`1px solid ${statusKind==="error"?"#3a1515":statusKind==="success"?"#1a3a28":"#1a2535"}`,
            }}>
              {statusMsg}
            </div>
          )}

          <div style={{borderTop:"1px solid #131e2b",margin:"16px 0"}}/>

          {/* ── Sex Display ── */}
          <div style={{fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:"10px"}}>
            Sex Display
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:"8px"}}>
            {[
              {v:"full",   label:"Full — Male♂ / Female♀"},
              {v:"symbol", label:"Symbol only — ♂ / ♀"},
            ].map(opt=>(
              <label key={opt.v} style={{
                display:"flex",alignItems:"center",gap:"10px",padding:"9px 12px",
                background: settings.sexDisplayMode===opt.v ? "#101e30" : "#080c11",
                border:`1px solid ${settings.sexDisplayMode===opt.v?"#1e4060":"#131e2b"}`,
                borderRadius:"5px",cursor:"pointer",
              }}>
                <input type="radio" name="sexDisplayMode" checked={settings.sexDisplayMode===opt.v}
                  onChange={()=>onChange({...settings,sexDisplayMode:opt.v})}
                  style={{accentColor:"#6aaccc"}}/>
                <span style={{fontSize:"12px",color:settings.sexDisplayMode===opt.v?"#c0d8e8":"#8a9aaa",fontFamily:"'Courier Prime',monospace"}}>
                  {opt.label}
                </span>
              </label>
            ))}
          </div>
          <div style={{borderTop:"1px solid #131e2b",margin:"16px 0"}}/>

          {/* ── Sex Colour Scheme ── */}
          <div style={{fontSize:"10px",color:"#4a6070",fontFamily:"'Courier Prime',monospace",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:"10px"}}>
            Sex Colour Scheme
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:"8px"}}>
            {[
              {v:"neutral",  label:"Neutral", desc:"Generic blue / red"},
              {v:"partisan", label:"Partisan (D/R)", desc:"Evokes the co-opted party branding"},
            ].map(opt=>(
              <label key={opt.v} style={{
                display:"flex",alignItems:"center",gap:"10px",padding:"9px 12px",
                background: settings.sexColorScheme===opt.v ? "#101e30" : "#080c11",
                border:`1px solid ${settings.sexColorScheme===opt.v?"#1e4060":"#131e2b"}`,
                borderRadius:"5px",cursor:"pointer",
              }}>
                <input type="radio" name="sexColorScheme" checked={settings.sexColorScheme===opt.v}
                  onChange={()=>onChange({...settings,sexColorScheme:opt.v})}
                  style={{accentColor:"#6aaccc"}}/>
                <span style={{flex:1,minWidth:0}}>
                  <span style={{display:"block",fontSize:"12px",color:settings.sexColorScheme===opt.v?"#c0d8e8":"#8a9aaa",fontFamily:"'Courier Prime',monospace"}}>
                    {opt.label}
                  </span>
                  <span style={{display:"block",fontSize:"10px",color:"#4a5a6a",marginTop:"1px"}}>
                    {opt.desc}
                  </span>
                </span>
                {/* Live swatches */}
                <span style={{display:"flex",gap:"5px",flexShrink:0}}>
                  {["Male","Female"].map(s=>(
                    <span key={s} style={{
                      width:"18px",height:"18px",borderRadius:"3px",
                      background: sexColorFor(s, opt.v),
                      boxShadow: settings.sexColorScheme===opt.v ? sexGlowFor(s, opt.v) : "none",
                    }}/>
                  ))}
                </span>
              </label>
            ))}
          </div>

          {/* ── Party letter (only meaningful with the partisan scheme) ── */}
          {settings.sexColorScheme === "partisan" && (
            <label style={{
              display:"flex",alignItems:"center",gap:"10px",padding:"9px 12px",marginTop:"8px",
              background: settings.showPartyLetter ? "#101e30" : "#080c11",
              border:`1px solid ${settings.showPartyLetter?"#1e4060":"#131e2b"}`,
              borderRadius:"5px",cursor:"pointer",
            }}>
              <input type="checkbox" checked={!!settings.showPartyLetter}
                onChange={e=>onChange({...settings,showPartyLetter:e.target.checked})}
                style={{accentColor:"#6aaccc"}}/>
              <span style={{flex:1}}>
                <span style={{display:"block",fontSize:"12px",color:settings.showPartyLetter?"#c0d8e8":"#8a9aaa",fontFamily:"'Courier Prime',monospace"}}>
                  Show party letter
                </span>
                <span style={{display:"block",fontSize:"10px",color:"#4a5a6a",marginTop:"1px"}}>
                  Prefixes badges as D·Male♂ / R·Female♀
                </span>
              </span>
            </label>
          )}

          <div style={{fontSize:"10px",color:"#2a3a4a",fontFamily:"'Courier Prime',monospace",marginTop:"18px",fontStyle:"italic"}}>
            More settings will appear here in future updates.
          </div>
        </div>
      </div>
    </div>
  );
}

// ── App (with settings provider) ────────────────────────────────────────────────

export default function App() {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [settingsLoaded, setSettingsLoaded] = useState(false);

  // Load settings on mount
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const s = await loadSettingsAsync();
      if (!cancelled) { setSettings(s); setSettingsLoaded(true); }
    })();
    return () => { cancelled = true; };
  }, []);

  // Persist settings on every change (after initial load)
  useEffect(() => {
    if (!settingsLoaded) return;
    saveSettingsAsync(settings);
  }, [settings, settingsLoaded]);

  return (
    <SettingsContext.Provider value={{settings, setSettings}}>
      <AppInner/>
    </SettingsContext.Provider>
  );
}
